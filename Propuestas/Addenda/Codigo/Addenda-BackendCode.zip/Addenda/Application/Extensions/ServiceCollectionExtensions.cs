using Addenda.Application.Interfaces;
using Addenda.Application.Services;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace Addenda.Application.Extensions;

/// <summary>
/// Registers the application layer. Each layer exposes its own extension method and the entry
/// point composes them, so adding a layer never means touching startup. Ver ryndem-dotnet/02.
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddValidatorsFromAssemblyContaining<AddendaAssemblyService>();

        services.AddScoped<IAddendaAssemblyService, AddendaAssemblyService>();
        services.AddScoped<IAddendaWriteService, AddendaWriteService>();

        return services;
    }
}
