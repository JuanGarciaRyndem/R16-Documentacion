using Addenda.Domain.Common;
using Addenda.Domain.Errors;
using FluentValidation.Results;

namespace Addenda.Application.Extensions;

/// <summary>
/// Converts a FluentValidation <see cref="ValidationResult"/> into the single-code, list-based
/// <see cref="Result"/> the application layer is allowed to produce (VAL-001, one entry per
/// field). This is the only place that calls the <c>internal</c> list overload of
/// <c>Result.Fail</c> — Domain grants it access via <c>InternalsVisibleTo</c>.
/// Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
internal static class ValidationResultExtensions
{
    public static Result ToFailureResult(this ValidationResult validationResult) =>
        Result.Fail(BuildErrors(validationResult));

    public static Result<T> ToFailureResult<T>(this ValidationResult validationResult) =>
        Result.Fail<T>(BuildErrors(validationResult));

    private static IReadOnlyList<ErrorDefinition> BuildErrors(ValidationResult validationResult) =>
        validationResult.Errors
            .Select(failure => AddendaErrors.Validacion.FalloDeValidacion with
            {
                Title = failure.ErrorMessage,
                Description = $"{failure.PropertyName}: {failure.ErrorMessage}",
            })
            .ToList();
}
