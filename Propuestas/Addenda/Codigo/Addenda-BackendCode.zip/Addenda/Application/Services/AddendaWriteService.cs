using Addenda.Application.DTOs;
using Addenda.Application.Extensions;
using Addenda.Application.Interfaces;
using Addenda.Domain.Common;
using Addenda.Domain.Entities;
using Addenda.Domain.Errors;
using Addenda.Domain.Interfaces;
using FluentValidation;

namespace Addenda.Application.Services;

/// <summary>
/// Persists the genuine addenda values captured for an order (BE-8). Header and line values are
/// added through the repository and committed together via <see cref="IUnitOfWork"/>, so a failure
/// partway through never leaves a header without its lines or the reverse.
/// </summary>
public sealed class AddendaWriteService : IAddendaWriteService
{
    private readonly ITipoAddendaRepository _tipoAddendaRepository;
    private readonly IAddendaRepository _addendaRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IValidator<SaveAddendaValuesRequestDto> _validator;

    public AddendaWriteService(
        ITipoAddendaRepository tipoAddendaRepository,
        IAddendaRepository addendaRepository,
        IUnitOfWork unitOfWork,
        IValidator<SaveAddendaValuesRequestDto> validator)
    {
        _tipoAddendaRepository = tipoAddendaRepository;
        _addendaRepository = addendaRepository;
        _unitOfWork = unitOfWork;
        _validator = validator;
    }

    public async Task<Result> SaveValuesAsync(SaveAddendaValuesRequestDto request, CancellationToken cancellationToken)
    {
        var validationResult = await _validator.ValidateAsync(request, cancellationToken);
        if (!validationResult.IsValid)
        {
            return validationResult.ToFailureResult();
        }

        var tipoAddenda = await _tipoAddendaRepository.ObtenerPorIdAsync(request.AddendaTypeId, cancellationToken);
        if (tipoAddenda is null || !tipoAddenda.Activo)
        {
            return Result.Fail(AddendaErrors.TipoAddenda.NoEncontradoOInactivo);
        }

        var ahora = DateTime.UtcNow;

        foreach (var valor in request.HeaderValues)
        {
            await _addendaRepository.AgregarCabeceraAsync(
                new AddendaCabecera
                {
                    IdTPPedido = request.OrderId,
                    IdCatTipoAddenda = request.AddendaTypeId,
                    Clave = valor.Key,
                    Valor = valor.Value,
                    FechaRegistro = ahora,
                    FechaUltimaActualizacion = ahora,
                },
                cancellationToken);
        }

        foreach (var linea in request.LineValues)
        {
            foreach (var valor in linea.Values)
            {
                await _addendaRepository.AgregarDetalleAsync(
                    new AddendaDetalle
                    {
                        IdTPPartidaPedido = linea.OrderLineId,
                        IdCatTipoAddenda = request.AddendaTypeId,
                        Clave = valor.Key,
                        Valor = valor.Value,
                        FechaRegistro = ahora,
                        FechaUltimaActualizacion = ahora,
                    },
                    cancellationToken);
            }
        }

        await _unitOfWork.GuardarCambiosAsync(cancellationToken);
        return Result.Ok();
    }
}
