using System.Globalization;
using Addenda.Application.DTOs;
using Addenda.Domain.Assembly;

namespace Addenda.Application.Services;

/// <summary>
/// Translates the English-language request DTOs into the derived-field dictionaries the domain's
/// <see cref="AddendaAssembler"/> expects, using the shared vocabulary in
/// <see cref="ClavesDeCamposDerivados"/>. This is the one place that knows both sides of the
/// naming split (ryndem-dotnet/01: Spanish in Domain, English in Application/API) — a template
/// factory in Infrastructure and this mapper are the only two places that reference
/// <see cref="ClavesDeCamposDerivados"/>, which is exactly what keeps a typo on either side from
/// going unnoticed until production.
/// </summary>
internal static class AddendaContextMapper
{
    public static Dictionary<string, string> MapFactura(InvoiceAddendaContextDto invoice) => new()
    {
        [ClavesDeCamposDerivados.Factura.RfcEmisor] = invoice.IssuerRfc,
        [ClavesDeCamposDerivados.Factura.EmpresaEmisora] = invoice.IssuerCompanyName,
        [ClavesDeCamposDerivados.Factura.FechaFacturacion] = invoice.InvoiceDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente] = invoice.CustomerPurchaseOrderNumber ?? string.Empty,
        [ClavesDeCamposDerivados.Factura.Moneda] = invoice.CurrencyCode,
        [ClavesDeCamposDerivados.Factura.Total] = invoice.Total.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Factura.MontoIva] = invoice.VatAmount.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Factura.TasaIva] = invoice.VatRate.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Factura.NumeroFactura] = invoice.InvoiceNumber,
        [ClavesDeCamposDerivados.Factura.Folio] = invoice.Folio,
        [ClavesDeCamposDerivados.Factura.TipoComprobante] = invoice.VoucherType,
    };

    public static Dictionary<string, string> MapPartida(InvoiceLineAddendaContextDto line) => new()
    {
        [ClavesDeCamposDerivados.Partida.Importe] = line.Amount.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.Cantidad] = line.Quantity.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.PrecioUnitario] = line.UnitPrice.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.UnidadDeMedida] = line.UnitOfMeasureCode,
        [ClavesDeCamposDerivados.Partida.TasaIva] = line.VatRate.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.MontoIva] = line.VatAmount.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.ImporteImpuestoTrasladado] = line.TransferredVatAmount.ToString(CultureInfo.InvariantCulture),
        [ClavesDeCamposDerivados.Partida.NumeroOrdenCompraCliente] = line.CustomerPurchaseOrderNumber ?? string.Empty,
    };
}
