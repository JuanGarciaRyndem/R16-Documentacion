using Addenda.Application.DTOs;
using Addenda.Application.Extensions;
using Addenda.Application.Interfaces;
using Addenda.Domain.Assembly;
using Addenda.Domain.Common;
using Addenda.Domain.Errors;
using Addenda.Domain.Interfaces;
using Addenda.Domain.Templates;
using FluentValidation;

namespace Addenda.Application.Services;

/// <summary>
/// Orchestrates addenda assembly (BE-4, BE-5, BE-7): loads the client's template and its captured
/// genuine values, resolves them against the invoice data the caller supplies, and hands the result
/// to <see cref="AddendaAssembler"/>. This class never resolves a field itself — that stays in the
/// domain motor — it only gathers the three inputs the motor needs.
/// </summary>
public sealed class AddendaAssemblyService : IAddendaAssemblyService
{
    private readonly ITipoAddendaRepository _tipoAddendaRepository;
    private readonly IAddendaRepository _addendaRepository;
    private readonly IAddendaTemplateProvider _templateProvider;
    private readonly IAddendaXmlSerializer _xmlSerializer;
    private readonly IValidator<AssembleAddendaRequestDto> _validator;

    public AddendaAssemblyService(
        ITipoAddendaRepository tipoAddendaRepository,
        IAddendaRepository addendaRepository,
        IAddendaTemplateProvider templateProvider,
        IAddendaXmlSerializer xmlSerializer,
        IValidator<AssembleAddendaRequestDto> validator)
    {
        _tipoAddendaRepository = tipoAddendaRepository;
        _addendaRepository = addendaRepository;
        _templateProvider = templateProvider;
        _xmlSerializer = xmlSerializer;
        _validator = validator;
    }

    public async Task<Result<AssembleAddendaResponseDto>> AssembleAsync(
        AssembleAddendaRequestDto request,
        CancellationToken cancellationToken)
    {
        var contextResult = await BuildAssemblyContextAsync(request, cancellationToken);
        if (contextResult.IsFailure)
        {
            return Result.Fail<AssembleAddendaResponseDto>(contextResult.Error);
        }

        var (plantilla, facturaContexto) = contextResult.Value;

        var ensambleResult = AddendaAssembler.Ensamblar(plantilla, facturaContexto);
        if (ensambleResult.IsFailure)
        {
            return Result.Fail<AssembleAddendaResponseDto>(ensambleResult.Error);
        }

        var xml = _xmlSerializer.Serializar(ensambleResult.Value);
        return Result.Ok(new AssembleAddendaResponseDto(request.OrderId, xml));
    }

    public async Task<Result> ValidateAsync(AssembleAddendaRequestDto request, CancellationToken cancellationToken)
    {
        var contextResult = await BuildAssemblyContextAsync(request, cancellationToken);
        if (contextResult.IsFailure)
        {
            return Result.Fail(contextResult.Error);
        }

        var (plantilla, facturaContexto) = contextResult.Value;
        return AddendaAssembler.Validar(plantilla, facturaContexto);
    }

    private async Task<Result<(AddendaTemplateDefinition Plantilla, FacturaAddendaContexto Contexto)>> BuildAssemblyContextAsync(
        AssembleAddendaRequestDto request,
        CancellationToken cancellationToken)
    {
        var validationResult = await _validator.ValidateAsync(request, cancellationToken);
        if (!validationResult.IsValid)
        {
            return validationResult.ToFailureResult<(AddendaTemplateDefinition, FacturaAddendaContexto)>();
        }

        var tipoAddenda = await _tipoAddendaRepository.ObtenerPorIdAsync(request.AddendaTypeId, cancellationToken);
        if (tipoAddenda is null || !tipoAddenda.Activo)
        {
            return Result.Fail<(AddendaTemplateDefinition, FacturaAddendaContexto)>(AddendaErrors.TipoAddenda.NoEncontradoOInactivo);
        }

        // Cubre tanto un catTipoAddenda inactivo/inexistente como uno activo sin plantilla
        // registrada en Infrastructure: en ambos casos el formato no está listo para usarse.
        var plantilla = _templateProvider.ObtenerPlantilla(tipoAddenda.Clave);
        if (plantilla is null)
        {
            return Result.Fail<(AddendaTemplateDefinition, FacturaAddendaContexto)>(AddendaErrors.TipoAddenda.NoEncontradoOInactivo);
        }

        var lineIds = request.Lines.Select(l => l.OrderLineId).ToList();

        var cabeceraGenuinos = await _addendaRepository.ObtenerCabeceraPorPedidoAsync(request.OrderId, cancellationToken);
        var valoresGenuinosCabecera = new Dictionary<string, string>();
        foreach (var valor in cabeceraGenuinos)
        {
            valoresGenuinosCabecera[valor.Clave] = valor.Valor;
        }

        var detalleGenuinos = await _addendaRepository.ObtenerDetallePorPartidasAsync(lineIds, cancellationToken);
        var valoresGenuinosPorPartida = detalleGenuinos
            .GroupBy(d => d.IdTPPartidaPedido)
            .ToDictionary(g => g.Key, g => g.ToDictionary(d => d.Clave, d => d.Valor));

        var partidas = request.Lines
            .Select(linea => new PartidaAddendaContexto(
                IdTPPartidaPedido: linea.OrderLineId,
                CamposDerivados: AddendaContextMapper.MapPartida(linea),
                ValoresGenuinos: valoresGenuinosPorPartida.TryGetValue(linea.OrderLineId, out var valores)
                    ? valores
                    : new Dictionary<string, string>()))
            .ToList();

        var contexto = new FacturaAddendaContexto(
            IdTPPedido: request.OrderId,
            CamposDerivados: AddendaContextMapper.MapFactura(request.Invoice),
            ValoresGenuinos: valoresGenuinosCabecera,
            Partidas: partidas);

        return Result.Ok((plantilla, contexto));
    }
}
