using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class InvoiceAddendaContextValidator : AbstractValidator<InvoiceAddendaContextDto>
{
    public InvoiceAddendaContextValidator()
    {
        RuleFor(x => x.IssuerRfc).NotEmpty().MaximumLength(13);
        RuleFor(x => x.IssuerCompanyName).NotEmpty();
        RuleFor(x => x.InvoiceDate).NotEmpty();
        RuleFor(x => x.CurrencyCode).NotEmpty().MaximumLength(3);
        RuleFor(x => x.Total).GreaterThanOrEqualTo(0);
        RuleFor(x => x.VatAmount).GreaterThanOrEqualTo(0);
        RuleFor(x => x.VatRate).GreaterThanOrEqualTo(0);
        RuleFor(x => x.InvoiceNumber).NotEmpty();
        RuleFor(x => x.Folio).NotEmpty();
        RuleFor(x => x.VoucherType).NotEmpty();
    }
}
