using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class AddendaKeyValueValidator : AbstractValidator<AddendaKeyValueDto>
{
    public AddendaKeyValueValidator()
    {
        RuleFor(x => x.Key).NotEmpty();
        RuleFor(x => x.Value).NotNull();
    }
}
