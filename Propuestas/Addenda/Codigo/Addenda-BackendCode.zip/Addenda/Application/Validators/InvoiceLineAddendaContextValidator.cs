using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class InvoiceLineAddendaContextValidator : AbstractValidator<InvoiceLineAddendaContextDto>
{
    public InvoiceLineAddendaContextValidator()
    {
        RuleFor(x => x.OrderLineId).NotEmpty();
        RuleFor(x => x.Amount).GreaterThanOrEqualTo(0);
        RuleFor(x => x.Quantity).GreaterThan(0);
        RuleFor(x => x.UnitPrice).GreaterThanOrEqualTo(0);
        RuleFor(x => x.UnitOfMeasureCode).NotEmpty();
        RuleFor(x => x.VatRate).GreaterThanOrEqualTo(0);
        RuleFor(x => x.VatAmount).GreaterThanOrEqualTo(0);
        RuleFor(x => x.TransferredVatAmount).GreaterThanOrEqualTo(0);
    }
}
