using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class AddendaLineValuesValidator : AbstractValidator<AddendaLineValuesDto>
{
    public AddendaLineValuesValidator()
    {
        RuleFor(x => x.OrderLineId).NotEmpty();
        RuleFor(x => x.Values).NotNull();
        RuleForEach(x => x.Values).SetValidator(new AddendaKeyValueValidator());
    }
}
