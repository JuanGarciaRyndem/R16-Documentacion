using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class AssembleAddendaRequestValidator : AbstractValidator<AssembleAddendaRequestDto>
{
    public AssembleAddendaRequestValidator()
    {
        RuleFor(x => x.OrderId).NotEmpty();
        RuleFor(x => x.AddendaTypeId).NotEmpty();
        RuleFor(x => x.Invoice).NotNull();
        RuleFor(x => x.Invoice).SetValidator(new InvoiceAddendaContextValidator()).When(x => x.Invoice is not null);
        RuleFor(x => x.Lines).NotNull();
        RuleForEach(x => x.Lines).SetValidator(new InvoiceLineAddendaContextValidator());
    }
}
