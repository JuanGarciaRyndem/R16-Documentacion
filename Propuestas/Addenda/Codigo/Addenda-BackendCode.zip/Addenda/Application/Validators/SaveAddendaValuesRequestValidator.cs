using Addenda.Application.DTOs;
using FluentValidation;

namespace Addenda.Application.Validators;

/// <summary>Format-only validation (ryndem-dotnet/04): shape of the data, never business rules.</summary>
public sealed class SaveAddendaValuesRequestValidator : AbstractValidator<SaveAddendaValuesRequestDto>
{
    public SaveAddendaValuesRequestValidator()
    {
        RuleFor(x => x.OrderId).NotEmpty();
        RuleFor(x => x.AddendaTypeId).NotEmpty();
        RuleFor(x => x.HeaderValues).NotNull();
        RuleForEach(x => x.HeaderValues).SetValidator(new AddendaKeyValueValidator());
        RuleFor(x => x.LineValues).NotNull();
        RuleForEach(x => x.LineValues).SetValidator(new AddendaLineValuesValidator());
    }
}
