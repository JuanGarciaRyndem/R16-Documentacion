namespace Addenda.Application.DTOs;

/// <summary>
/// Request to assemble the <c>cfdi:Addenda</c> fragment for one order, or to validate that it can
/// be assembled before stamping (see <c>IAddendaAssemblyService.ValidateAsync</c>, which reuses
/// this same DTO). Corresponds to tasks BE-4/BE-5/BE-7 of the estimation.
/// </summary>
/// <param name="OrderId">The order being invoiced (tpPedido).</param>
/// <param name="AddendaTypeId">The client's addenda format (catTipoAddenda.IdCatTipoAddenda).</param>
/// <param name="Invoice">Header-level data already known from the invoice.</param>
/// <param name="Lines">Per-line data for every invoiced line, in the order they must appear.</param>
public sealed record AssembleAddendaRequestDto(
    Guid OrderId,
    Guid AddendaTypeId,
    InvoiceAddendaContextDto Invoice,
    IReadOnlyList<InvoiceLineAddendaContextDto> Lines);
