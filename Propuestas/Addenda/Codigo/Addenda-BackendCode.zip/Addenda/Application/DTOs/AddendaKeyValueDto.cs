namespace Addenda.Application.DTOs;

/// <summary>
/// One captured genuine addenda value. <see cref="Key"/> matches the <c>Clave</c> the client's
/// template expects (e.g. "CorreoContacto", "LineaDeOrden") — this is the atomic Clave/Valor pair
/// the generic model is built on. See "[PROPUESTA] Adenda de Factura - Impacto en BD.md", section 5.
/// </summary>
public sealed record AddendaKeyValueDto(string Key, string Value);
