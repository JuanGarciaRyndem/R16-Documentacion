namespace Addenda.Application.DTOs;

/// <summary>Genuine addenda values captured for one specific order line.</summary>
/// <param name="OrderLineId">The line these values belong to (tpPartidaPedido).</param>
/// <param name="Values">The captured Clave/Valor pairs for that line.</param>
public sealed record AddendaLineValuesDto(Guid OrderLineId, IReadOnlyList<AddendaKeyValueDto> Values);
