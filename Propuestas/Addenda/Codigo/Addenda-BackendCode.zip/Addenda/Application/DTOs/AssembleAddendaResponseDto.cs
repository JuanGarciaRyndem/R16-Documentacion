namespace Addenda.Application.DTOs;

/// <summary>Result of assembling an addenda: the ready-to-insert XML fragment.</summary>
/// <param name="OrderId">Echoes the order the fragment was assembled for.</param>
/// <param name="Xml">
/// The addenda fragment only — it does not include the <c>cfdi:Addenda</c> wrapper, so the caller
/// (Finanzas/pqf) inserts it into the CFDI it is already building.
/// </param>
public sealed record AssembleAddendaResponseDto(Guid OrderId, string Xml);
