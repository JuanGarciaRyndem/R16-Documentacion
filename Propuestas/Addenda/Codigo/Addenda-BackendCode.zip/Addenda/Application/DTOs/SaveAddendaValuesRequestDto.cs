namespace Addenda.Application.DTOs;

/// <summary>
/// Request to persist the genuine addenda values captured for an order — the small set of data
/// that only exists for addenda purposes (fccAddenda / fccAddendaPartida). Corresponds to task
/// BE-8 of the estimation: header and line values are saved as a single transaction, since a
/// header without its line values (or vice versa) is an inconsistent addenda.
/// </summary>
/// <param name="OrderId">The order these values belong to (tpPedido).</param>
/// <param name="AddendaTypeId">The client's addenda format, to validate it is enabled for addenda.</param>
/// <param name="HeaderValues">Header-level genuine values (e.g. Sanofi's "CorreoContacto").</param>
/// <param name="LineValues">Per-line genuine values (e.g. "LineaDeOrden"), one entry per line that has any.</param>
public sealed record SaveAddendaValuesRequestDto(
    Guid OrderId,
    Guid AddendaTypeId,
    IReadOnlyList<AddendaKeyValueDto> HeaderValues,
    IReadOnlyList<AddendaLineValuesDto> LineValues);
