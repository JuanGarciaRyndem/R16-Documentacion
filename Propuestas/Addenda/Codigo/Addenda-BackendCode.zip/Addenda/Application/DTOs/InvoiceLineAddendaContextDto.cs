namespace Addenda.Application.DTOs;

/// <summary>
/// Line-level invoice data needed to assemble the repeating detail block of an addenda (Pfizer,
/// Asofarma, Sanofi), supplied by the caller for every invoiced line. Mavi's template has no
/// detail block and simply receives an empty list. See "[PROPUESTA] Adenda de Factura - Impacto en
/// Backend.md", section 5.3.
/// </summary>
/// <param name="OrderLineId">Identifies the source line (tpPartidaPedido) this context belongs to.</param>
/// <param name="Amount">Line amount before tax.</param>
/// <param name="Quantity">Invoiced quantity.</param>
/// <param name="UnitPrice">Unit price.</param>
/// <param name="UnitOfMeasureCode">Unit of measure code as recorded on the line.</param>
/// <param name="VatRate">VAT rate applied to this line.</param>
/// <param name="VatAmount">VAT amount for this line.</param>
/// <param name="TransferredVatAmount">Transferred VAT amount for this line (impuesto trasladado).</param>
/// <param name="CustomerPurchaseOrderNumber">
/// The client's purchase order number for this specific line, when the format repeats it per line
/// instead of carrying it once at header level (this is Pfizer's case).
/// </param>
public sealed record InvoiceLineAddendaContextDto(
    Guid OrderLineId,
    decimal Amount,
    decimal Quantity,
    decimal UnitPrice,
    string UnitOfMeasureCode,
    decimal VatRate,
    decimal VatAmount,
    decimal TransferredVatAmount,
    string? CustomerPurchaseOrderNumber);
