namespace Addenda.Application.DTOs;

/// <summary>
/// Header-level invoice data needed to assemble an addenda, supplied by the caller (Finanzas/pqf)
/// on every request. This module never reads fccFactura directly: by the time an invoice is about
/// to be stamped, the caller already has this data in memory, so sending it inline avoids a second
/// round trip and keeps Addenda decoupled from the invoicing schema. See "[PROPUESTA] Adenda de
/// Factura - Impacto en Backend.md", section 5.3.
/// </summary>
/// <param name="IssuerRfc">RFC of the invoice issuer.</param>
/// <param name="IssuerCompanyName">Legal name of the issuing company.</param>
/// <param name="InvoiceDate">Invoice stamping date.</param>
/// <param name="CustomerPurchaseOrderNumber">
/// The client's purchase order number, when the invoice carries one. Optional: not every format
/// requires it at header level (some only require it per line).
/// </param>
/// <param name="CurrencyCode">ISO currency code (e.g. "MXN", "USD").</param>
/// <param name="Total">Invoice total.</param>
/// <param name="VatAmount">Total VAT amount.</param>
/// <param name="VatRate">VAT rate applied (e.g. 0.16).</param>
/// <param name="InvoiceNumber">Internal invoice number/series-folio as issued.</param>
/// <param name="Folio">CFDI folio.</param>
/// <param name="VoucherType">CFDI voucher type (e.g. "I").</param>
public sealed record InvoiceAddendaContextDto(
    string IssuerRfc,
    string IssuerCompanyName,
    DateOnly InvoiceDate,
    string? CustomerPurchaseOrderNumber,
    string CurrencyCode,
    decimal Total,
    decimal VatAmount,
    decimal VatRate,
    string InvoiceNumber,
    string Folio,
    string VoucherType);
