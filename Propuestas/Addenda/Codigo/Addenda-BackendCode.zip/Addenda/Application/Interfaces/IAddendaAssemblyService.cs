using Addenda.Application.DTOs;
using Addenda.Domain.Common;

namespace Addenda.Application.Interfaces;

/// <summary>
/// Orchestrates the assembly of an order's <c>cfdi:Addenda</c> fragment: loads the client's
/// template and its captured genuine values, resolves them against the invoice data the caller
/// supplies, and serializes the result. Corresponds to tasks BE-4, BE-5 and BE-7 of the estimation.
/// </summary>
public interface IAddendaAssemblyService
{
    /// <summary>Assembles the addenda and returns the ready-to-insert XML fragment.</summary>
    Task<Result<AssembleAddendaResponseDto>> AssembleAsync(AssembleAddendaRequestDto request, CancellationToken cancellationToken);

    /// <summary>
    /// Runs the same resolution as <see cref="AssembleAsync"/> without serializing, so the caller
    /// can reject a stamping attempt before it commits to one (task BE-7).
    /// </summary>
    Task<Result> ValidateAsync(AssembleAddendaRequestDto request, CancellationToken cancellationToken);
}
