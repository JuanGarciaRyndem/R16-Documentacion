using Addenda.Application.DTOs;
using Addenda.Domain.Common;

namespace Addenda.Application.Interfaces;

/// <summary>
/// Persists the genuine addenda values captured for an order. Corresponds to task BE-8 of the
/// estimation.
/// </summary>
public interface IAddendaWriteService
{
    /// <summary>
    /// Saves header and line values as a single transaction: a header without its line values (or
    /// the reverse) would leave the addenda inconsistent.
    /// </summary>
    Task<Result> SaveValuesAsync(SaveAddendaValuesRequestDto request, CancellationToken cancellationToken);
}
