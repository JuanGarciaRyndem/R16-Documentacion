using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Addenda.Testing")]
