using Microsoft.VisualStudio.TestTools.UnitTesting;

// Configuración común de la suite (ryndem-dotnet/09-testing). Las pruebas de este proyecto no
// comparten estado ni dependen de orden de ejecución, así que se paralelizan por método.
[assembly: Parallelize(Workers = 0, Scope = ExecutionScope.MethodLevel)]
