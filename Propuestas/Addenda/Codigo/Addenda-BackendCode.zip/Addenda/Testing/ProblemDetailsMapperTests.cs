using Addenda.API.Extensions;
using Addenda.Domain.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

[TestClass]
public sealed class ProblemDetailsMapperTests
{
    [TestMethod]
    public void ToProblemDetails_ErrorDelCatalogo_CopiaCodeStatusYCorrelationId()
    {
        var problemDetails = ProblemDetailsMapper.ToProblemDetails(
            AddendaErrors.TipoAddenda.NoEncontradoOInactivo,
            correlationId: "c-123",
            typeBase: "https://errors.ryndem.mx/addenda");

        Assert.AreEqual("ADD-001", problemDetails.Extensions["code"]);
        Assert.AreEqual("c-123", problemDetails.Extensions["correlationId"]);
        Assert.AreEqual(404, problemDetails.Status);
        Assert.AreEqual("https://errors.ryndem.mx/addenda/ADD-001", problemDetails.Type);
        Assert.AreEqual(AddendaErrors.TipoAddenda.NoEncontradoOInactivo.Title, problemDetails.Title);
    }

    [TestMethod]
    public void ToProblemDetails_SinErroresAdicionales_NoAgregaLaExtensionErrors()
    {
        var problemDetails = ProblemDetailsMapper.ToProblemDetails(
            AddendaErrors.Generico.NoClasificado,
            correlationId: "c-1",
            typeBase: "https://errors.ryndem.mx/addenda");

        Assert.IsFalse(problemDetails.Extensions.ContainsKey("errors"));
    }

    [TestMethod]
    public void ToProblemDetails_VariosErroresDeValidacion_AgregaLaExtensionErrorsConCadaUno()
    {
        var errorCampo1 = AddendaErrors.Validacion.FalloDeValidacion with { Description = "OrderId: es requerido" };
        var errorCampo2 = AddendaErrors.Validacion.FalloDeValidacion with { Description = "AddendaTypeId: es requerido" };

        var problemDetails = ProblemDetailsMapper.ToProblemDetails(
            errorCampo1,
            correlationId: "c-1",
            typeBase: "https://errors.ryndem.mx/addenda",
            erroresAdicionales: [errorCampo1, errorCampo2]);

        Assert.IsTrue(problemDetails.Extensions.ContainsKey("errors"));
    }
}
