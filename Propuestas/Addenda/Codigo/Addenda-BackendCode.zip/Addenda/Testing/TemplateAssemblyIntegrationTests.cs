using Addenda.Domain.Assembly;
using Addenda.Domain.Errors;
using Addenda.Infrastructure.Templates;
using Addenda.Infrastructure.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

/// <summary>
/// Valida las 4 plantillas reales (<see cref="AddendaTemplateProvider"/>) contra los ejemplos
/// literales de "INFORMACIÓN DE NODOS DE ADENDAS.pdf" — los mismos casos sugeridos en
/// "[PROPUESTA] Adenda de Factura - Impacto en Backend.md", sección 6. Ejercita la plantilla, el
/// motor de ensamblado y el serializador juntos: es exactamente el escenario que el plan de
/// rollout de ese documento (sección 7, paso 4) pide validar "byte a byte" antes de apagar la
/// escritura dual — esta suite es el punto de partida de esa validación, no el reemplazo de
/// correrla contra el ambiente real una vez compilada la solución.
/// </summary>
[TestClass]
public sealed class TemplateAssemblyIntegrationTests
{
    private static readonly AddendaTemplateProvider Plantillas = new();
    private static readonly AddendaXmlSerializer Serializador = new();

    private static string Ensamblar(string clave, FacturaAddendaContexto contexto)
    {
        var plantilla = Plantillas.ObtenerPlantilla(clave) ?? throw new InvalidOperationException($"No hay plantilla registrada para '{clave}'.");
        var resultado = AddendaAssembler.Ensamblar(plantilla, contexto);
        Assert.IsTrue(resultado.IsSuccess, resultado.IsFailure ? resultado.Error.Description : string.Empty);
        return Serializador.Serializar(resultado.Value);
    }

    [TestMethod]
    public void MaviAddendaTemplateFactory_PedidoDelPdf_GeneraElXmlEsperado()
    {
        var contexto = new FacturaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Factura.RfcEmisor] = "PQF910416FB3",
                [ClavesDeCamposDerivados.Factura.FechaFacturacion] = "2026-08-04",
                [ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente] = "9586",
                [ClavesDeCamposDerivados.Factura.Moneda] = "USD",
                [ClavesDeCamposDerivados.Factura.Total] = "953.52",
                [ClavesDeCamposDerivados.Factura.MontoIva] = "131.52",
                [ClavesDeCamposDerivados.Factura.TasaIva] = "0.00",
                [ClavesDeCamposDerivados.Factura.NumeroFactura] = "A148237",
                [ClavesDeCamposDerivados.Factura.TipoComprobante] = "I",
                [ClavesDeCamposDerivados.Factura.Folio] = "148237",
            },
            ValoresGenuinos: new Dictionary<string, string>(),
            Partidas: []);

        var xml = Ensamblar("MAVI", contexto);

        const string esperado =
            "<Mavi>" +
            "<RfcProveedor>PQF910416FB3</RfcProveedor>" +
            "<NumProveedor>704</NumProveedor>" +
            "<FechaFacturacion>2026-08-04</FechaFacturacion>" +
            "<NumPedido>9586</NumPedido>" +
            "<CodMoneda>USD</CodMoneda>" +
            "<MontoTotal>953.52</MontoTotal>" +
            "<IVA>131.52</IVA>" +
            "<PorcentajeIVA>0.00</PorcentajeIVA>" +
            "<NumFactura>A148237</NumFactura>" +
            "<Serie>A</Serie>" +
            "<Folio>148237</Folio>" +
            "</Mavi>";

        Assert.AreEqual(esperado, xml);
    }

    [TestMethod]
    public void PfizerAddendaTemplateFactory_TresPartidasDelPdf_GeneraElXmlEsperado()
    {
        var partidas = new[]
        {
            PartidaPfizer(lineaDeOrden: "1", amount: "209.00"),
            PartidaPfizer(lineaDeOrden: "2", amount: "209.00"),
            PartidaPfizer(lineaDeOrden: "3", amount: "270.00"),
        };

        var contexto = new FacturaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string>(), new Dictionary<string, string>(), partidas);

        var xml = Ensamblar("PFIZER", contexto);

        const string esperado =
            "<Pfizer_Ebox TipoAddenda=\"1\">" +
            "<PfizerPO InstruccionesAdicionales=\"N/A\">" +
            "<Lineas AMOUNT=\"209.00\" LINE_NO=\"1\" PO_NUMBER=\"9501315099\" QUANTITY=\"1.0\" TAX_CODE=\"F2\" />" +
            "<Lineas AMOUNT=\"209.00\" LINE_NO=\"2\" PO_NUMBER=\"9501315099\" QUANTITY=\"1.0\" TAX_CODE=\"F2\" />" +
            "<Lineas AMOUNT=\"270.00\" LINE_NO=\"3\" PO_NUMBER=\"9501315099\" QUANTITY=\"1.0\" TAX_CODE=\"F2\" />" +
            "</PfizerPO>" +
            "</Pfizer_Ebox>";

        Assert.AreEqual(esperado, xml);
    }

    [TestMethod]
    public void PfizerAddendaTemplateFactory_PartidaConTasaIvaCero_UsaTaxCodeF1()
    {
        var partida = PartidaPfizer(lineaDeOrden: "1", amount: "100.00", tasaIva: "0");
        var contexto = new FacturaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string>(), new Dictionary<string, string>(), [partida]);

        var xml = Ensamblar("PFIZER", contexto);

        StringAssert.Contains(xml, "TAX_CODE=\"F1\"");
    }

    private static PartidaAddendaContexto PartidaPfizer(string lineaDeOrden, string amount, string tasaIva = "0.16") =>
        new(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Partida.Importe] = amount,
                [ClavesDeCamposDerivados.Partida.NumeroOrdenCompraCliente] = "9501315099",
                [ClavesDeCamposDerivados.Partida.Cantidad] = "1.0",
                [ClavesDeCamposDerivados.Partida.TasaIva] = tasaIva,
            },
            ValoresGenuinos: new Dictionary<string, string> { ["LineaDeOrden"] = lineaDeOrden });

    [TestMethod]
    public void AsofarmaAddendaTemplateFactory_CuatroPartidasDelPdf_GeneraElXmlEsperado()
    {
        var partidas = new[]
        {
            PartidaAsofarma(noPartida: "53", ivaAcreditable: "58.88"),
            PartidaAsofarma(noPartida: "54", ivaAcreditable: "89.60"),
            PartidaAsofarma(noPartida: "55", ivaAcreditable: "105.76"),
            PartidaAsofarma(noPartida: "56", ivaAcreditable: "134.72"),
        };

        var contexto = new FacturaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Factura.Folio] = "139732",
                [ClavesDeCamposDerivados.Factura.EmpresaEmisora] = "PROVEEDORA",
                [ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente] = "OC076015",
            },
            ValoresGenuinos: new Dictionary<string, string>(),
            Partidas: partidas);

        var xml = Ensamblar("ASOFARMA", contexto);

        const string esperado =
            "<ASONIOSCOC folio=\"139732\" noProveedor=\"220476\" ordenCompra=\"OC076015\" serie=\"A\" tipoProveedor=\"2\">" +
            "<Partidas>" +
            "<Partida Otros=\"0\" ivaAcreditable=\"58.88\" ivaDevengado=\"0.00\" noPartida=\"53\" />" +
            "<Partida Otros=\"0\" ivaAcreditable=\"89.60\" ivaDevengado=\"0.00\" noPartida=\"54\" />" +
            "<Partida Otros=\"0\" ivaAcreditable=\"105.76\" ivaDevengado=\"0.00\" noPartida=\"55\" />" +
            "<Partida Otros=\"0\" ivaAcreditable=\"134.72\" ivaDevengado=\"0.00\" noPartida=\"56\" />" +
            "</Partidas>" +
            "</ASONIOSCOC>";

        Assert.AreEqual(esperado, xml);
    }

    [TestMethod]
    public void AsofarmaAddendaTemplateFactory_EmisorGolocaer_UsaNoProveedor221961()
    {
        var contexto = new FacturaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Factura.Folio] = "1",
                [ClavesDeCamposDerivados.Factura.EmpresaEmisora] = "GOLOCAER",
                [ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente] = "OC1",
            },
            ValoresGenuinos: new Dictionary<string, string>(),
            Partidas: []);

        var xml = Ensamblar("ASOFARMA", contexto);

        StringAssert.Contains(xml, "noProveedor=\"221961\"");
    }

    private static PartidaAddendaContexto PartidaAsofarma(string noPartida, string ivaAcreditable) =>
        new(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string> { [ClavesDeCamposDerivados.Partida.ImporteImpuestoTrasladado] = ivaAcreditable },
            ValoresGenuinos: new Dictionary<string, string> { ["LineaDeOrden"] = noPartida });

    [TestMethod]
    public void SanofiAddendaTemplateFactory_CabeceraYUnaPartidaDelPdf_ResuelveTodosLosCamposDelHeader()
    {
        // El fragmento completo se valida por sub-cadenas y no por igualdad exacta de todo el
        // string: la declaración explícita de xmlns:xsi (ver SanofiAddendaTemplateFactory) hace
        // que el orden de atributos del nodo raíz dependa del comportamiento interno de
        // System.Xml.Linq al resolver namespaces, que este sandbox no puede compilar ni ejecutar
        // para confirmar byte a byte (ver limitación de entorno en el README). Los valores de cada
        // campo sí son literales del PDF y se verifican uno a uno.
        var contexto = ContextoSanofi();

        var xml = Ensamblar("SANOFI", contexto);

        StringAssert.Contains(xml, "<sanofi:TIPO_DOCTO>01</sanofi:TIPO_DOCTO>");
        StringAssert.Contains(xml, "<sanofi:NUM_ORDEN>C000191021</sanofi:NUM_ORDEN>");
        StringAssert.Contains(xml, "<sanofi:NUM_PROVEEDOR>0001050470</sanofi:NUM_PROVEEDOR>");
        StringAssert.Contains(xml, "<sanofi:FCTCONV>1.000</sanofi:FCTCONV>");
        StringAssert.Contains(xml, "<sanofi:MONEDA>USD</sanofi:MONEDA>");
        StringAssert.Contains(xml, "<sanofi:CTA_CORREO>credito@proquifa.com.mx</sanofi:CTA_CORREO>");
        StringAssert.Contains(xml, "<sanofi:IMP_RETENCION />");
        StringAssert.Contains(xml, "<sanofi:IMP_TOTAL>220.40</sanofi:IMP_TOTAL>");
        // Sin CorreoContacto capturado: debe usar el default, tal como el propio ejemplo del PDF.
        StringAssert.Contains(xml, "<sanofi:CORREO_SANOFI>Paola.Espinoza@sanofi.com</sanofi:CORREO_SANOFI>");
        StringAssert.Contains(xml, "<sanofi:NUM_LINEA>0001</sanofi:NUM_LINEA>");
        StringAssert.Contains(xml, "<sanofi:NUM_ENTRADA>0000000000</sanofi:NUM_ENTRADA>");
        // Sin CuentaPuente capturado: debe usar el default (doc de BD, pendiente #3).
        StringAssert.Contains(xml, "<sanofi:CUENTA_PUENTE>0000000000</sanofi:CUENTA_PUENTE>");
        StringAssert.Contains(xml, "<sanofi:UNIDADES>1.000</sanofi:UNIDADES>");
        StringAssert.Contains(xml, "<sanofi:PRECIO_UNITARIO>190.00</sanofi:PRECIO_UNITARIO>");
        StringAssert.Contains(xml, "<sanofi:IMPORTE>190.00</sanofi:IMPORTE>");
        StringAssert.Contains(xml, "<sanofi:UNIDAD_MEDIDA>Pieza</sanofi:UNIDAD_MEDIDA>");
        StringAssert.Contains(xml, "<sanofi:TASA_IVA>0.16</sanofi:TASA_IVA>");
        StringAssert.Contains(xml, "<sanofi:IMPORTE_IVA>30.40</sanofi:IMPORTE_IVA>");
        StringAssert.StartsWith(xml, "<sanofi:sanofi ");
        StringAssert.Contains(xml, "xmlns:sanofi=\"https://mexico.sanofi.com/schemas\"");
        StringAssert.Contains(xml, "version=\"1.0\"");
        StringAssert.Contains(xml, "xsi:schemaLocation=\"https://mexico.sanofi.com/schemas https://mexico.sanofi.com/schemas/sanofi.xsd\"");
    }

    [TestMethod]
    public void SanofiAddendaTemplateFactory_CorreoContactoCapturado_UsaElValorCapturadoNoElDefault()
    {
        var contexto = ContextoSanofi(correoContacto: "compras@cliente.com");

        var xml = Ensamblar("SANOFI", contexto);

        StringAssert.Contains(xml, "<sanofi:CORREO_SANOFI>compras@cliente.com</sanofi:CORREO_SANOFI>");
    }

    [TestMethod]
    public void AddendaAssembler_ClienteConDetallePorPartidaSinLineaDeOrdenCapturada_FallaAntesDeTimbrar()
    {
        var partidaSinLineaDeOrden = new PartidaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Partida.Cantidad] = "1.000",
                [ClavesDeCamposDerivados.Partida.PrecioUnitario] = "190.00",
                [ClavesDeCamposDerivados.Partida.Importe] = "190.00",
                [ClavesDeCamposDerivados.Partida.UnidadDeMedida] = "Pieza",
                [ClavesDeCamposDerivados.Partida.TasaIva] = "0.16",
                [ClavesDeCamposDerivados.Partida.MontoIva] = "30.40",
            },
            ValoresGenuinos: new Dictionary<string, string>());

        var contexto = ContextoSanofi() with { Partidas = [partidaSinLineaDeOrden] };

        var plantilla = Plantillas.ObtenerPlantilla("SANOFI")!;
        var resultado = AddendaAssembler.Validar(plantilla, contexto);

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Partida.FaltaValorObligatorio, resultado.Error);
    }

    private static FacturaAddendaContexto ContextoSanofi(string? correoContacto = null)
    {
        var partida = new PartidaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Partida.Cantidad] = "1.000",
                [ClavesDeCamposDerivados.Partida.PrecioUnitario] = "190.00",
                [ClavesDeCamposDerivados.Partida.Importe] = "190.00",
                [ClavesDeCamposDerivados.Partida.UnidadDeMedida] = "Pieza",
                [ClavesDeCamposDerivados.Partida.TasaIva] = "0.16",
                [ClavesDeCamposDerivados.Partida.MontoIva] = "30.40",
            },
            ValoresGenuinos: new Dictionary<string, string> { ["LineaDeOrden"] = "0001" });

        var valoresGenuinosCabecera = correoContacto is null
            ? new Dictionary<string, string>()
            : new Dictionary<string, string> { ["CorreoContacto"] = correoContacto };

        return new FacturaAddendaContexto(
            Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>
            {
                [ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente] = "C000191021",
                [ClavesDeCamposDerivados.Factura.Moneda] = "USD",
                [ClavesDeCamposDerivados.Factura.Total] = "220.40",
            },
            ValoresGenuinos: valoresGenuinosCabecera,
            Partidas: [partida]);
    }
}
