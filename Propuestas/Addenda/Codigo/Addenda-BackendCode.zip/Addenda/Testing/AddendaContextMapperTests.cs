using Addenda.Application.DTOs;
using Addenda.Application.Services;
using Addenda.Domain.Assembly;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

/// <summary>
/// <see cref="AddendaContextMapper"/> tiene lógica de formateo (fecha, decimales con cultura
/// invariante) — ryndem-dotnet/09 exige prueba para todo mapeo con lógica, no solo para los
/// directos. Accesible desde este proyecto por <c>InternalsVisibleTo</c> en
/// <c>Application/AssemblyInfo.cs</c>.
/// </summary>
[TestClass]
public sealed class AddendaContextMapperTests
{
    [TestMethod]
    public void MapFactura_DatosDeLaFactura_UsaLasClavesDeClavesDeCamposDerivados()
    {
        var invoice = new InvoiceAddendaContextDto(
            IssuerRfc: "PQF910416FB3",
            IssuerCompanyName: "Proveedora Químico Farmacéutica",
            InvoiceDate: new DateOnly(2026, 8, 4),
            CustomerPurchaseOrderNumber: "9586",
            CurrencyCode: "USD",
            Total: 953.52m,
            VatAmount: 131.52m,
            VatRate: 0.00m,
            InvoiceNumber: "A148237",
            Folio: "148237",
            VoucherType: "I");

        var mapa = AddendaContextMapper.MapFactura(invoice);

        Assert.AreEqual("PQF910416FB3", mapa[ClavesDeCamposDerivados.Factura.RfcEmisor]);
        Assert.AreEqual("2026-08-04", mapa[ClavesDeCamposDerivados.Factura.FechaFacturacion]);
        Assert.AreEqual("9586", mapa[ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente]);
        Assert.AreEqual("USD", mapa[ClavesDeCamposDerivados.Factura.Moneda]);
        Assert.AreEqual("953.52", mapa[ClavesDeCamposDerivados.Factura.Total]);
        Assert.AreEqual("131.52", mapa[ClavesDeCamposDerivados.Factura.MontoIva]);
        Assert.AreEqual("0.00", mapa[ClavesDeCamposDerivados.Factura.TasaIva]);
        Assert.AreEqual("A148237", mapa[ClavesDeCamposDerivados.Factura.NumeroFactura]);
        Assert.AreEqual("I", mapa[ClavesDeCamposDerivados.Factura.TipoComprobante]);
        Assert.AreEqual("148237", mapa[ClavesDeCamposDerivados.Factura.Folio]);
    }

    [TestMethod]
    public void MapFactura_SinOrdenDeCompraDelCliente_UsaCadenaVacia()
    {
        var invoice = new InvoiceAddendaContextDto(
            "PQF910416FB3", "Proveedora", new DateOnly(2026, 8, 4), CustomerPurchaseOrderNumber: null,
            "USD", 1m, 0m, 0m, "A1", "1", "I");

        var mapa = AddendaContextMapper.MapFactura(invoice);

        Assert.AreEqual(string.Empty, mapa[ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente]);
    }

    [TestMethod]
    public void MapPartida_DatosDeLaPartida_UsaLasClavesDeClavesDeCamposDerivados()
    {
        var line = new InvoiceLineAddendaContextDto(
            OrderLineId: Guid.NewGuid(),
            Amount: 190.00m,
            Quantity: 1.000m,
            UnitPrice: 190.00m,
            UnitOfMeasureCode: "Pieza",
            VatRate: 0.16m,
            VatAmount: 30.40m,
            TransferredVatAmount: 58.88m,
            CustomerPurchaseOrderNumber: "9501315099");

        var mapa = AddendaContextMapper.MapPartida(line);

        Assert.AreEqual("190.00", mapa[ClavesDeCamposDerivados.Partida.Importe]);
        Assert.AreEqual("1.000", mapa[ClavesDeCamposDerivados.Partida.Cantidad]);
        Assert.AreEqual("190.00", mapa[ClavesDeCamposDerivados.Partida.PrecioUnitario]);
        Assert.AreEqual("Pieza", mapa[ClavesDeCamposDerivados.Partida.UnidadDeMedida]);
        Assert.AreEqual("0.16", mapa[ClavesDeCamposDerivados.Partida.TasaIva]);
        Assert.AreEqual("30.40", mapa[ClavesDeCamposDerivados.Partida.MontoIva]);
        Assert.AreEqual("58.88", mapa[ClavesDeCamposDerivados.Partida.ImporteImpuestoTrasladado]);
        Assert.AreEqual("9501315099", mapa[ClavesDeCamposDerivados.Partida.NumeroOrdenCompraCliente]);
    }
}
