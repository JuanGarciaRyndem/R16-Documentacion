using Addenda.Domain.Assembly;
using Addenda.Domain.Errors;
using Addenda.Domain.Templates;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

/// <summary>
/// Pruebas del motor genérico (<see cref="AddendaAssembler"/>) usando plantillas mínimas armadas a
/// mano — no las de ningún cliente real — para aislar cada regla de resolución de campo del detalle
/// de un formato concreto. Las plantillas reales (Mavi/Pfizer/Asofarma/Sanofi) se validan contra los
/// ejemplos del PDF en <see cref="TemplateAssemblyIntegrationTests"/>.
/// </summary>
[TestClass]
public sealed class AddendaAssemblerTests
{
    private static FacturaAddendaContexto ContextoVacio(IReadOnlyList<PartidaAddendaContexto>? partidas = null) =>
        new(
            IdTPPedido: Guid.NewGuid(),
            CamposDerivados: new Dictionary<string, string>(),
            ValoresGenuinos: new Dictionary<string, string>(),
            Partidas: partidas ?? []);

    [TestMethod]
    public void Ensamblar_CampoFijo_UsaElValorFijo()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Fijo("Campo", "704", FormaSerializacion.Elemento)]));

        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsSuccess);
        Assert.AreEqual("704", resultado.Value.Hijos.Single().Valor);
    }

    [TestMethod]
    public void Ensamblar_CampoDerivadoExistente_UsaElValorDelContexto()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Derivado("Campo", "Moneda", FormaSerializacion.Elemento)]));

        var contexto = new FacturaAddendaContexto(
            Guid.NewGuid(),
            new Dictionary<string, string> { ["Moneda"] = "USD" },
            new Dictionary<string, string>(),
            []);

        var resultado = AddendaAssembler.Ensamblar(plantilla, contexto);

        Assert.IsTrue(resultado.IsSuccess);
        Assert.AreEqual("USD", resultado.Value.Hijos.Single().Valor);
    }

    [TestMethod]
    public void Ensamblar_CampoDerivadoFaltante_FallaConDatosDeFacturaNoEncontrados()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Derivado("Campo", "Moneda", FormaSerializacion.Elemento)]));

        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Ensamblado.DatosDeFacturaNoEncontrados, resultado.Error);
    }

    [TestMethod]
    public void Ensamblar_CampoGenuinoCapturado_UsaElValorCapturado()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Genuino("CorreoContacto", FormaSerializacion.Elemento)]));

        var contexto = new FacturaAddendaContexto(
            Guid.NewGuid(),
            new Dictionary<string, string>(),
            new Dictionary<string, string> { ["CorreoContacto"] = "compras@cliente.com" },
            []);

        var resultado = AddendaAssembler.Ensamblar(plantilla, contexto);

        Assert.IsTrue(resultado.IsSuccess);
        Assert.AreEqual("compras@cliente.com", resultado.Value.Hijos.Single().Valor);
    }

    [TestMethod]
    public void Ensamblar_CampoGenuinoSinCapturarConDefault_UsaElDefault()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion(
                "Raiz",
                [AddendaCampoDefinicion.Genuino("CorreoContacto", FormaSerializacion.Elemento, valorPorDefecto: "Paola.Espinoza@sanofi.com")]));

        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsSuccess);
        Assert.AreEqual("Paola.Espinoza@sanofi.com", resultado.Value.Hijos.Single().Valor);
    }

    [TestMethod]
    public void Ensamblar_CampoGenuinoSinCapturarSinDefaultACabecera_FallaConFaltaValorObligatorioDeCabecera()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Genuino("LineaDeOrden", FormaSerializacion.Atributo)]));

        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Cabecera.FaltaValorObligatorio, resultado.Error);
    }

    [TestMethod]
    public void Ensamblar_CampoGenuinoSinCapturarSinDefaultAPartida_FallaConFaltaValorObligatorioDePartida()
    {
        var detalle = new AddendaNodoDefinicion(
            "Linea",
            [AddendaCampoDefinicion.Genuino("LineaDeOrden", FormaSerializacion.Atributo)],
            SeRepitePorPartida: true);

        var plantilla = new AddendaTemplateDefinition("TEST", new AddendaNodoDefinicion("Raiz", [], Hijos: [detalle]));

        var partida = new PartidaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string>(), new Dictionary<string, string>());
        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio([partida]));

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Partida.FaltaValorObligatorio, resultado.Error);
    }

    [TestMethod]
    public void Ensamblar_ReglaConMapeoCoincidente_UsaElValorMapeado()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion(
                "Raiz",
                [
                    AddendaCampoDefinicion.Derivado(
                        "TAX_CODE",
                        "TasaIva",
                        FormaSerializacion.Atributo,
                        regla: new Dictionary<string, string> { ["0"] = "F1", ["*"] = "F2" }),
                ]));

        var contexto = new FacturaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string> { ["TasaIva"] = "0" }, new Dictionary<string, string>(), []);
        var resultado = AddendaAssembler.Ensamblar(plantilla, contexto);

        Assert.IsTrue(resultado.IsSuccess);
        Assert.AreEqual("F1", resultado.Value.Atributos["TAX_CODE"]);
    }

    [TestMethod]
    public void Ensamblar_ReglaSinMapeoNiDefault_FallaConValorSinMapeoEnRegla()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion(
                "Raiz",
                [
                    AddendaCampoDefinicion.Derivado(
                        "noProveedor",
                        "EmpresaEmisora",
                        FormaSerializacion.Atributo,
                        regla: new Dictionary<string, string> { ["PROVEEDORA"] = "220476", ["GOLOCAER"] = "221961" }),
                ]));

        var contexto = new FacturaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string> { ["EmpresaEmisora"] = "OTRO_EMISOR" }, new Dictionary<string, string>(), []);
        var resultado = AddendaAssembler.Ensamblar(plantilla, contexto);

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Ensamblado.ValorSinMapeoEnRegla, resultado.Error);
    }

    [TestMethod]
    public void Ensamblar_NodoSeRepitePorPartida_GeneraUnHijoPorCadaPartida()
    {
        var detalle = new AddendaNodoDefinicion(
            "Linea",
            [AddendaCampoDefinicion.Derivado("Importe", "Importe", FormaSerializacion.Atributo)],
            SeRepitePorPartida: true);

        var plantilla = new AddendaTemplateDefinition("TEST", new AddendaNodoDefinicion("Raiz", [], Hijos: [detalle]));

        var partidas = new[]
        {
            new PartidaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string> { ["Importe"] = "100" }, new Dictionary<string, string>()),
            new PartidaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string> { ["Importe"] = "200" }, new Dictionary<string, string>()),
            new PartidaAddendaContexto(Guid.NewGuid(), new Dictionary<string, string> { ["Importe"] = "300" }, new Dictionary<string, string>()),
        };

        var resultado = AddendaAssembler.Ensamblar(plantilla, ContextoVacio(partidas));

        Assert.IsTrue(resultado.IsSuccess);
        CollectionAssert.AreEqual(
            new[] { "100", "200", "300" },
            resultado.Value.Hijos.Select(h => h.Atributos["Importe"]).ToArray());
    }

    [TestMethod]
    public void Validar_EnsambladoExitoso_RegresaOk()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Fijo("Campo", "704", FormaSerializacion.Elemento)]));

        var resultado = AddendaAssembler.Validar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsSuccess);
    }

    [TestMethod]
    public void Validar_EnsambladoFallido_PropagaElMismoError()
    {
        var plantilla = new AddendaTemplateDefinition(
            "TEST",
            new AddendaNodoDefinicion("Raiz", [AddendaCampoDefinicion.Genuino("LineaDeOrden", FormaSerializacion.Atributo)]));

        var resultado = AddendaAssembler.Validar(plantilla, ContextoVacio());

        Assert.IsTrue(resultado.IsFailure);
        Assert.AreEqual(AddendaErrors.Cabecera.FaltaValorObligatorio, resultado.Error);
    }
}
