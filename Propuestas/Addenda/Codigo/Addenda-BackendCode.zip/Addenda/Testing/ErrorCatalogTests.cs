using Addenda.Domain.Errors;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

[TestClass]
public sealed class ErrorCatalogTests
{
    [TestMethod]
    public void AddendaErrors_Todos_CodigosSonUnicos()
    {
        var codigos = AddendaErrors.Todos.Select(e => e.Code).ToList();

        Assert.AreEqual(codigos.Count, codigos.Distinct().Count(), "Hay al menos un Code repetido en AddendaErrors.Todos.");
    }

    [TestMethod]
    public void AddendaErrors_Todos_TodosDeclaranUnHttpStatusCodeValido()
    {
        Assert.IsTrue(AddendaErrors.Todos.All(e => e.HttpStatusCode is >= 400 and < 600));
    }
}
