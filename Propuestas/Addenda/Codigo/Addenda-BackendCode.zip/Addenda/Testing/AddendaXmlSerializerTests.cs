using Addenda.Domain.Assembly;
using Addenda.Infrastructure.Xml;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Addenda.Testing;

/// <summary>
/// Pruebas del serializador en aislamiento, con árboles <see cref="AddendaXmlNodo"/> armados a
/// mano — no las plantillas reales (ver <see cref="TemplateAssemblyIntegrationTests"/> para esas).
/// </summary>
[TestClass]
public sealed class AddendaXmlSerializerTests
{
    private readonly AddendaXmlSerializer _serializador = new();

    [TestMethod]
    public void Serializar_NodoSinHijosNiValor_GeneraElementoAutocerrado()
    {
        var nodo = new AddendaXmlNodo { Nombre = "IMP_RETENCION" };

        var xml = _serializador.Serializar(nodo);

        Assert.AreEqual("<IMP_RETENCION />", xml);
    }

    [TestMethod]
    public void Serializar_NodoConValorDeTexto_LoUsaComoContenidoDelElemento()
    {
        var nodo = new AddendaXmlNodo { Nombre = "Folio", Valor = "148237" };

        var xml = _serializador.Serializar(nodo);

        Assert.AreEqual("<Folio>148237</Folio>", xml);
    }

    [TestMethod]
    public void Serializar_NodoConAtributos_LosSerializaEnElElemento()
    {
        var nodo = new AddendaXmlNodo
        {
            Nombre = "Partida",
            Atributos = new Dictionary<string, string> { ["Otros"] = "0", ["noPartida"] = "53" },
        };

        var xml = _serializador.Serializar(nodo);

        Assert.AreEqual("<Partida Otros=\"0\" noPartida=\"53\" />", xml);
    }

    [TestMethod]
    public void Serializar_NodoConHijos_LosSerializaEnElOrdenDeLaLista()
    {
        var nodo = new AddendaXmlNodo
        {
            Nombre = "Mavi",
            Hijos =
            [
                new AddendaXmlNodo { Nombre = "NumProveedor", Valor = "704" },
                new AddendaXmlNodo { Nombre = "CodMoneda", Valor = "USD" },
            ],
        };

        var xml = _serializador.Serializar(nodo);

        Assert.AreEqual("<Mavi><NumProveedor>704</NumProveedor><CodMoneda>USD</CodMoneda></Mavi>", xml);
    }

    [TestMethod]
    public void Serializar_NamespaceDeclaradoEnElNodoPadre_LoHeredanLosNodosHijosConElMismoPrefijo()
    {
        var nodo = new AddendaXmlNodo
        {
            Nombre = "sanofi:sanofi",
            Atributos = new Dictionary<string, string> { ["xmlns:sanofi"] = "https://mexico.sanofi.com/schemas" },
            Hijos =
            [
                new AddendaXmlNodo
                {
                    Nombre = "sanofi:header",
                    Hijos = [new AddendaXmlNodo { Nombre = "sanofi:TIPO_DOCTO", Valor = "01" }],
                },
            ],
        };

        var xml = _serializador.Serializar(nodo);

        StringAssert.Contains(xml, "<sanofi:header>");
        StringAssert.Contains(xml, "<sanofi:TIPO_DOCTO>01</sanofi:TIPO_DOCTO>");
        // La declaración de namespace vive una sola vez, en el nodo raíz — los hijos no la repiten.
        Assert.AreEqual(1, xml.Split("xmlns:sanofi").Length - 1);
    }
}
