using Addenda.Domain.Interfaces;
using Addenda.Infrastructure.Persistence.Context;
using Addenda.Infrastructure.Persistence.Repository;
using Addenda.Infrastructure.Templates;
using Addenda.Infrastructure.Xml;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Addenda.Infrastructure.Extensions;

/// <summary>
/// Registra la capa de infraestructura. Cada capa expone su propio método de extensión y el punto
/// de entrada los compone. Ver ryndem-dotnet/02.
/// </summary>
public static class ServiceCollectionExtensions
{
    private const string ConnectionStringName = "AddendaDatabase";

    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString(ConnectionStringName)
            ?? throw new InvalidOperationException($"Falta la cadena de conexión '{ConnectionStringName}'.");

        // Sin migraciones automáticas al arrancar (ryndem-dotnet/11): el esquema se aplica por
        // pipeline de despliegue, no en Program.cs.
        services.AddDbContext<AddendaDbContext>(options => options.UseSqlServer(connectionString));

        services.AddScoped<ITipoAddendaRepository, TipoAddendaRepository>();
        services.AddScoped<IAddendaRepository, AddendaRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        // Sin estado y sin dependencias: una sola instancia para todo el proceso construye las 4
        // plantillas una vez (ver AddendaTemplateProvider), en vez de reconstruirlas por request.
        services.AddSingleton<IAddendaTemplateProvider, AddendaTemplateProvider>();
        services.AddSingleton<IAddendaXmlSerializer, AddendaXmlSerializer>();

        return services;
    }
}
