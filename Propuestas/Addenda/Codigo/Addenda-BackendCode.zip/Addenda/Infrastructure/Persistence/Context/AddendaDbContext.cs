using Addenda.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Addenda.Infrastructure.Persistence.Context;

/// <summary>
/// Contexto de datos del módulo de Addenda: <c>catTipoAddenda</c>, <c>fccAddenda</c> y
/// <c>fccAddendaPartida</c>. Configurado por Fluent API (ver <c>Configurations/</c>), sin
/// anotaciones sobre las entidades — el dominio no debe conocer Entity Framework.
/// No se ejecutan migraciones automáticas al arrancar: ver <c>Program.cs</c> y ryndem-dotnet/11.
/// </summary>
public sealed class AddendaDbContext : DbContext
{
    public AddendaDbContext(DbContextOptions<AddendaDbContext> options)
        : base(options)
    {
    }

    public DbSet<TipoAddenda> TiposAddenda => Set<TipoAddenda>();

    public DbSet<AddendaCabecera> AddendasCabecera => Set<AddendaCabecera>();

    public DbSet<AddendaDetalle> AddendasDetalle => Set<AddendaDetalle>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AddendaDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }
}
