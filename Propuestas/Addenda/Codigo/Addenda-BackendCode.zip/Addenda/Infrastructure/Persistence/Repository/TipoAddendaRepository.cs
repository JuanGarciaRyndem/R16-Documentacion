using Addenda.Domain.Entities;
using Addenda.Domain.Interfaces;
using Addenda.Infrastructure.Persistence.Context;
using Microsoft.EntityFrameworkCore;

namespace Addenda.Infrastructure.Persistence.Repository;

public sealed class TipoAddendaRepository : ITipoAddendaRepository
{
    private readonly AddendaDbContext _dbContext;

    public TipoAddendaRepository(AddendaDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<TipoAddenda?> ObtenerPorIdAsync(Guid idCatTipoAddenda, CancellationToken cancellationToken) =>
        DbExceptionTranslator.EjecutarAsync(() =>
            _dbContext.TiposAddenda
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.IdCatTipoAddenda == idCatTipoAddenda, cancellationToken));

    public Task<TipoAddenda?> ObtenerPorClaveAsync(string clave, CancellationToken cancellationToken) =>
        DbExceptionTranslator.EjecutarAsync(() =>
            _dbContext.TiposAddenda
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.Clave == clave, cancellationToken));
}
