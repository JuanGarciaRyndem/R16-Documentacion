using Addenda.Domain.Interfaces;
using Addenda.Infrastructure.Persistence.Context;

namespace Addenda.Infrastructure.Persistence.Repository;

public sealed class UnitOfWork : IUnitOfWork
{
    private readonly AddendaDbContext _dbContext;

    public UnitOfWork(AddendaDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<int> GuardarCambiosAsync(CancellationToken cancellationToken) =>
        DbExceptionTranslator.EjecutarAsync(() => _dbContext.SaveChangesAsync(cancellationToken));
}
