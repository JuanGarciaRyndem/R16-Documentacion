using Addenda.Domain.Entities;
using Addenda.Domain.Interfaces;
using Addenda.Infrastructure.Persistence.Context;
using Microsoft.EntityFrameworkCore;

namespace Addenda.Infrastructure.Persistence.Repository;

/// <summary>
/// <c>AgregarCabeceraAsync</c>/<c>AgregarDetalleAsync</c> solo hacen <c>Add</c> sobre el
/// <see cref="AddendaDbContext"/>: no llaman <c>SaveChanges</c> por su cuenta — eso es
/// responsabilidad de <see cref="UnitOfWork"/>, para que guardar cabecera y detalle de una addenda
/// se confirme como una sola transacción (tarea BE-8). Ver ryndem-dotnet/02.
/// </summary>
public sealed class AddendaRepository : IAddendaRepository
{
    private readonly AddendaDbContext _dbContext;

    public AddendaRepository(AddendaDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<IReadOnlyList<AddendaCabecera>> ObtenerCabeceraPorPedidoAsync(Guid idTPPedido, CancellationToken cancellationToken) =>
        DbExceptionTranslator.EjecutarAsync<IReadOnlyList<AddendaCabecera>>(async () =>
            await _dbContext.AddendasCabecera
                .AsNoTracking()
                .Where(a => a.IdTPPedido == idTPPedido)
                .ToListAsync(cancellationToken));

    public Task<IReadOnlyList<AddendaDetalle>> ObtenerDetallePorPartidasAsync(
        IReadOnlyList<Guid> idsTPPartidaPedido,
        CancellationToken cancellationToken) =>
        DbExceptionTranslator.EjecutarAsync<IReadOnlyList<AddendaDetalle>>(async () =>
            await _dbContext.AddendasDetalle
                .AsNoTracking()
                .Where(d => idsTPPartidaPedido.Contains(d.IdTPPartidaPedido))
                .ToListAsync(cancellationToken));

    public async Task AgregarCabeceraAsync(AddendaCabecera valor, CancellationToken cancellationToken) =>
        await _dbContext.AddendasCabecera.AddAsync(valor, cancellationToken);

    public async Task AgregarDetalleAsync(AddendaDetalle valor, CancellationToken cancellationToken) =>
        await _dbContext.AddendasDetalle.AddAsync(valor, cancellationToken);
}
