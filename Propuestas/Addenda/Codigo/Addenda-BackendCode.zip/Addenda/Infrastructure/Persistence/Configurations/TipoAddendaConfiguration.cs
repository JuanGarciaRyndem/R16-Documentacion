using Addenda.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Addenda.Infrastructure.Persistence.Configurations;

/// <summary>Mapeo de <c>catTipoAddenda</c>. Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.</summary>
public sealed class TipoAddendaConfiguration : IEntityTypeConfiguration<TipoAddenda>
{
    public void Configure(EntityTypeBuilder<TipoAddenda> builder)
    {
        builder.ToTable("catTipoAddenda");

        builder.HasKey(t => t.IdCatTipoAddenda);

        builder.Property(t => t.IdCatTipoAddenda).HasColumnName("IdCatTipoAddenda").ValueGeneratedOnAdd();
        builder.Property(t => t.Clave).HasColumnName("Clave").HasMaxLength(30).IsRequired();
        builder.Property(t => t.Descripcion).HasColumnName("Descripcion").HasMaxLength(100).IsRequired();
        builder.Property(t => t.TieneDetallePorPartida).HasColumnName("TieneDetallePorPartida").IsRequired();
        builder.Property(t => t.RequiereCorreoContacto).HasColumnName("RequiereCorreoContacto").IsRequired();
        builder.Property(t => t.Activo).HasColumnName("Activo").IsRequired();

        builder.HasIndex(t => t.Clave).IsUnique();
    }
}
