using Addenda.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Addenda.Infrastructure.Persistence.Configurations;

/// <summary>Mapeo de <c>fccAddendaPartida</c>. Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.</summary>
public sealed class AddendaDetalleConfiguration : IEntityTypeConfiguration<AddendaDetalle>
{
    public void Configure(EntityTypeBuilder<AddendaDetalle> builder)
    {
        builder.ToTable("fccAddendaPartida");

        builder.HasKey(d => d.IdFccAddendaPartida);

        builder.Property(d => d.IdFccAddendaPartida).HasColumnName("IdFccAddendaPartida").ValueGeneratedOnAdd();
        builder.Property(d => d.IdTPPartidaPedido).HasColumnName("IdTPPartidaPedido").IsRequired();
        builder.Property(d => d.IdCatTipoAddenda).HasColumnName("IdCatTipoAddenda").IsRequired();
        builder.Property(d => d.Clave).HasColumnName("Clave").HasMaxLength(100).IsRequired();
        builder.Property(d => d.Valor).HasColumnName("Valor").HasMaxLength(500).IsRequired();
        builder.Property(d => d.FechaRegistro).HasColumnName("FechaRegistro").IsRequired();
        builder.Property(d => d.FechaUltimaActualizacion).HasColumnName("FechaUltimaActualizacion").IsRequired();

        builder.HasIndex(d => new { d.IdTPPartidaPedido, d.Clave });
    }
}
