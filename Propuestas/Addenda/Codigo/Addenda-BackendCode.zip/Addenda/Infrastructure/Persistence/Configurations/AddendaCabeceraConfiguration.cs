using Addenda.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Addenda.Infrastructure.Persistence.Configurations;

/// <summary>Mapeo de <c>fccAddenda</c>. Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.</summary>
public sealed class AddendaCabeceraConfiguration : IEntityTypeConfiguration<AddendaCabecera>
{
    public void Configure(EntityTypeBuilder<AddendaCabecera> builder)
    {
        builder.ToTable("fccAddenda");

        builder.HasKey(a => a.IdFccAddenda);

        builder.Property(a => a.IdFccAddenda).HasColumnName("IdFccAddenda").ValueGeneratedOnAdd();
        builder.Property(a => a.IdTPPedido).HasColumnName("IdTPPedido").IsRequired();
        builder.Property(a => a.IdCatTipoAddenda).HasColumnName("IdCatTipoAddenda").IsRequired();
        builder.Property(a => a.Clave).HasColumnName("Clave").HasMaxLength(100).IsRequired();
        builder.Property(a => a.Valor).HasColumnName("Valor").HasMaxLength(500).IsRequired();
        builder.Property(a => a.FechaGeneracion).HasColumnName("FechaGeneracion");
        builder.Property(a => a.FechaRegistro).HasColumnName("FechaRegistro").IsRequired();
        builder.Property(a => a.FechaUltimaActualizacion).HasColumnName("FechaUltimaActualizacion").IsRequired();

        // No hay FK a fccAddendaPartida y viceversa (ver Domain/Entities/AddendaDetalle.cs): cada
        // una cuelga directo de su origen (pedido / partida), no una de la otra.
        builder.HasIndex(a => new { a.IdTPPedido, a.Clave });
    }
}
