using System.Data.Common;
using Addenda.Domain.Errors;
using Microsoft.EntityFrameworkCore;

namespace Addenda.Infrastructure.Persistence;

/// <summary>
/// Clasificador dedicado que traduce una falla de Entity Framework a un flujo inesperado del
/// dominio (ryndem-dotnet/05: "las excepciones de base de datos se traducen a errores del dominio
/// mediante un clasificador dedicado, que decide además si son transitorias"). Es la única pieza de
/// Infrastructure que conoce el tipo concreto de excepción de EF Core / ADO.NET.
/// </summary>
/// <remarks>
/// Cubre <see cref="DbUpdateException"/> (falla al guardar) y <see cref="DbException"/> (falla del
/// proveedor ADO.NET al ejecutar una consulta, p. ej. <c>SqlException</c> — que deriva de
/// <see cref="DbException"/> sin que este proyecto necesite referenciar el paquete concreto del
/// proveedor). Cualquier otra excepción no es de este clasificador y se deja propagar tal cual,
/// para que la capture <c>GlobalFallbackExceptionHandler</c> como <c>UNX-001</c>.
/// </remarks>
internal static class DbExceptionTranslator
{
    public static async Task EjecutarAsync(Func<Task> operacion)
    {
        try
        {
            await operacion();
        }
        catch (Exception ex) when (ex is DbUpdateException or DbException)
        {
            throw new SemanticException(AddendaErrors.Infraestructura.NoDisponible, ex);
        }
    }

    public static async Task<T> EjecutarAsync<T>(Func<Task<T>> operacion)
    {
        try
        {
            return await operacion();
        }
        catch (Exception ex) when (ex is DbUpdateException or DbException)
        {
            throw new SemanticException(AddendaErrors.Infraestructura.NoDisponible, ex);
        }
    }
}
