using Addenda.Domain.Interfaces;
using Addenda.Domain.Templates;
using Addenda.Infrastructure.Templates.Definitions;

namespace Addenda.Infrastructure.Templates;

/// <summary>
/// Registro en memoria de las plantillas de los 4 formatos vigentes (6 clientes — Sanofi, Sanofi
/// Pasteur y Azteca Vacunas comparten estructura pero se registran como 3 entradas independientes,
/// ver doc de BD pendiente #2). Agregar un cliente que reutiliza un formato existente es una línea
/// nueva aquí, no una clase nueva — es justo lo que busca el diseño data-driven (ver
/// "[PROPUESTA] Adenda de Factura - Impacto en Backend.md", sección 5.1).
/// </summary>
public sealed class AddendaTemplateProvider : IAddendaTemplateProvider
{
    private readonly IReadOnlyDictionary<string, AddendaTemplateDefinition> _plantillasPorClave;

    public AddendaTemplateProvider()
    {
        var plantillas = new[]
        {
            MaviAddendaTemplateFactory.Crear(),
            PfizerAddendaTemplateFactory.Crear(),
            AsofarmaAddendaTemplateFactory.Crear(),
            SanofiAddendaTemplateFactory.Crear("SANOFI", numeroProveedor: "0001050470", correoContactoPorDefecto: "Paola.Espinoza@sanofi.com"),
            // Mismos valores que Sanofi hasta que SAP confirme si Sanofi Pasteur y Azteca Vacunas
            // usan un NUM_PROVEEDOR o correo default distintos (doc de BD, pendiente #2).
            SanofiAddendaTemplateFactory.Crear("SANOFI_PASTEUR", numeroProveedor: "0001050470", correoContactoPorDefecto: "Paola.Espinoza@sanofi.com"),
            SanofiAddendaTemplateFactory.Crear("AZTECA_VACUNAS", numeroProveedor: "0001050470", correoContactoPorDefecto: "Paola.Espinoza@sanofi.com"),
        };

        _plantillasPorClave = plantillas.ToDictionary(p => p.ClaveTipoAddenda, StringComparer.OrdinalIgnoreCase);
    }

    public AddendaTemplateDefinition? ObtenerPlantilla(string claveTipoAddenda) =>
        _plantillasPorClave.GetValueOrDefault(claveTipoAddenda);
}
