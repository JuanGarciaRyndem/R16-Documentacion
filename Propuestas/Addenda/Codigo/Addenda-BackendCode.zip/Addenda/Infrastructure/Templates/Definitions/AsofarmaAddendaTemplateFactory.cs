using Addenda.Domain.Assembly;
using Addenda.Domain.Templates;

namespace Addenda.Infrastructure.Templates.Definitions;

/// <summary>
/// Plantilla del formato Asofarma: <c>ASONIOSCOC</c> &gt; <c>Partidas</c> &gt; N × <c>Partida</c>,
/// una por partida facturada. Todos los campos se serializan como atributos. Estructura tomada
/// literal de "INFORMACIÓN DE NODOS DE ADENDAS.pdf", página 4.
/// </summary>
/// <remarks>
/// Ejemplo real del PDF:
/// <code>
/// &lt;ASONIOSCOC folio="139732" noProveedor="220476" ordenCompra="OC076015" serie="A" tipoProveedor="2"&gt;
///   &lt;Partidas&gt;
///     &lt;Partida Otros="0" ivaAcreditable="58.88" ivaDevengado="0.00" noPartida="53"/&gt;
///   &lt;/Partidas&gt;
/// &lt;/ASONIOSCOC&gt;
/// </code>
/// </remarks>
internal static class AsofarmaAddendaTemplateFactory
{
    private const string Clave = "ASOFARMA";

    public static AddendaTemplateDefinition Crear()
    {
        var partida = new AddendaNodoDefinicion(
            Nombre: "Partida",
            SeRepitePorPartida: true,
            Campos:
            [
                AddendaCampoDefinicion.Fijo("Otros", "0", FormaSerializacion.Atributo),
                AddendaCampoDefinicion.Derivado("ivaAcreditable", ClavesDeCamposDerivados.Partida.ImporteImpuestoTrasladado, FormaSerializacion.Atributo),
                AddendaCampoDefinicion.Fijo("ivaDevengado", "0.00", FormaSerializacion.Atributo),
                // noPartida es el único campo genuino: el mismo concepto que "LineaDeOrden" en
                // fccAddendaPartida (ver doc de BD, sección 3.3).
                AddendaCampoDefinicion.Genuino("noPartida", FormaSerializacion.Atributo, claveGenuina: "LineaDeOrden"),
            ]);

        var partidas = new AddendaNodoDefinicion(Nombre: "Partidas", Campos: [], Hijos: [partida]);

        var asonioscoc = new AddendaNodoDefinicion(
            Nombre: "ASONIOSCOC",
            Campos:
            [
                AddendaCampoDefinicion.Derivado("folio", ClavesDeCamposDerivados.Factura.Folio, FormaSerializacion.Atributo),
                // Mapeo fijo por empresa emisora (doc de BD, pendiente #5: confirmar que solo
                // existen estos 2 emisores). Sin "*": si aparece un tercer emisor, el ensamblado
                // debe fallar con ADD-006 en vez de adivinar un valor.
                AddendaCampoDefinicion.Derivado(
                    "noProveedor",
                    ClavesDeCamposDerivados.Factura.EmpresaEmisora,
                    FormaSerializacion.Atributo,
                    regla: new Dictionary<string, string> { ["PROVEEDORA"] = "220476", ["GOLOCAER"] = "221961" }),
                AddendaCampoDefinicion.Derivado("ordenCompra", ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente, FormaSerializacion.Atributo),
                AddendaCampoDefinicion.Fijo("serie", "A", FormaSerializacion.Atributo),
                AddendaCampoDefinicion.Fijo("tipoProveedor", "2", FormaSerializacion.Atributo),
            ],
            Hijos: [partidas]);

        return new AddendaTemplateDefinition(Clave, asonioscoc);
    }
}
