using Addenda.Domain.Assembly;
using Addenda.Domain.Templates;

namespace Addenda.Infrastructure.Templates.Definitions;

/// <summary>
/// Plantilla del formato Mavi: un único nodo de cabecera, sin detalle por partida — el más simple
/// de los 4 formatos y el único sin ningún campo genuino. Estructura tomada literal de
/// "INFORMACIÓN DE NODOS DE ADENDAS.pdf", página 3.
/// </summary>
/// <remarks>
/// Ejemplo real del PDF:
/// <code>
/// &lt;Mavi&gt;
///   &lt;RfcProveedor&gt;PQF910416FB3&lt;/RfcProveedor&gt;
///   &lt;NumProveedor&gt;704&lt;/NumProveedor&gt;
///   &lt;FechaFacturacion&gt;2026-08-04&lt;/FechaFacturacion&gt;
///   &lt;NumPedido&gt;9586&lt;/NumPedido&gt;
///   &lt;CodMoneda&gt;USD&lt;/CodMoneda&gt;
///   &lt;MontoTotal&gt;953.52&lt;/MontoTotal&gt;
///   &lt;IVA&gt;131.52&lt;/IVA&gt;
///   &lt;PorcentajeIVA&gt;0.00&lt;/PorcentajeIVA&gt;
///   &lt;NumFactura&gt;A148237&lt;/NumFactura&gt;
///   &lt;Serie&gt;A&lt;/Serie&gt;
///   &lt;Folio&gt;148237&lt;/Folio&gt;
/// &lt;/Mavi&gt;
/// </code>
/// </remarks>
internal static class MaviAddendaTemplateFactory
{
    private const string Clave = "MAVI";

    public static AddendaTemplateDefinition Crear()
    {
        var nodoRaiz = new AddendaNodoDefinicion(
            Nombre: "Mavi",
            Campos:
            [
                AddendaCampoDefinicion.Derivado("RfcProveedor", ClavesDeCamposDerivados.Factura.RfcEmisor, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("NumProveedor", "704", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("FechaFacturacion", ClavesDeCamposDerivados.Factura.FechaFacturacion, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("NumPedido", ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("CodMoneda", ClavesDeCamposDerivados.Factura.Moneda, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("MontoTotal", ClavesDeCamposDerivados.Factura.Total, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("IVA", ClavesDeCamposDerivados.Factura.MontoIva, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("PorcentajeIVA", ClavesDeCamposDerivados.Factura.TasaIva, FormaSerializacion.Elemento),
                // NumFactura = serie concatenada con folio (p. ej. "A148237"): ya viaja armado en
                // Factura.NumeroFactura — el motor no concatena, así que ese valor debe llegar
                // ya formado desde Application (ver InvoiceAddendaContextDto.InvoiceNumber).
                AddendaCampoDefinicion.Derivado("NumFactura", ClavesDeCamposDerivados.Factura.NumeroFactura, FormaSerializacion.Elemento),
                // Serie: "A" para comprobantes de Ingreso ("I"), "P" para Pago ("P") — regla fija
                // de 2 valores tomada literal del PDF, sección Mavi, punto 10. "*" cubre cualquier
                // otro tipo de comprobante con el mismo default que usa hoy el legacy ("A").
                AddendaCampoDefinicion.Derivado(
                    "Serie",
                    ClavesDeCamposDerivados.Factura.TipoComprobante,
                    FormaSerializacion.Elemento,
                    regla: new Dictionary<string, string> { ["I"] = "A", ["P"] = "P", ["*"] = "A" }),
                AddendaCampoDefinicion.Derivado("Folio", ClavesDeCamposDerivados.Factura.Folio, FormaSerializacion.Elemento),
            ]);

        return new AddendaTemplateDefinition(Clave, nodoRaiz);
    }
}
