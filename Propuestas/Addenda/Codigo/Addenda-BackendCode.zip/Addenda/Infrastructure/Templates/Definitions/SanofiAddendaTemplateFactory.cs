using Addenda.Domain.Assembly;
using Addenda.Domain.Templates;

namespace Addenda.Infrastructure.Templates.Definitions;

/// <summary>
/// Plantilla del formato Sanofi: nodo raíz <c>sanofi:sanofi</c> con namespace propio, un
/// <c>sanofi:header</c> y N × <c>sanofi:details</c> (uno por partida). Comparten este formato
/// Sanofi, Sanofi Pasteur y Azteca Vacunas — de ahí que <see cref="Crear"/> reciba los valores que
/// el documento de BD (pendiente #2) marca como posiblemente distintos por cliente
/// (<c>NUM_PROVEEDOR</c> y el correo default) en vez de darlos por fijos para los 3.
/// Estructura tomada literal de "INFORMACIÓN DE NODOS DE ADENDAS.pdf", páginas 5-6.
/// </summary>
/// <remarks>
/// Ejemplo real del PDF (Sanofi):
/// <code>
/// &lt;sanofi:sanofi xmlns:sanofi="https://mexico.sanofi.com/schemas" version="1.0"
///                xsi:schemaLocation="https://mexico.sanofi.com/schemas https://mexico.sanofi.com/schemas/sanofi.xsd"&gt;
///   &lt;sanofi:header&gt;
///     &lt;sanofi:TIPO_DOCTO&gt;01&lt;/sanofi:TIPO_DOCTO&gt;
///     &lt;sanofi:NUM_ORDEN&gt;C000191021&lt;/sanofi:NUM_ORDEN&gt;
///     &lt;sanofi:NUM_PROVEEDOR&gt;0001050470&lt;/sanofi:NUM_PROVEEDOR&gt;
///     &lt;sanofi:FCTCONV&gt;1.000&lt;/sanofi:FCTCONV&gt;
///     &lt;sanofi:MONEDA&gt;USD&lt;/sanofi:MONEDA&gt;
///     &lt;sanofi:CTA_CORREO&gt;credito@proquifa.com.mx&lt;/sanofi:CTA_CORREO&gt;
///     &lt;sanofi:IMP_RETENCION/&gt;
///     &lt;sanofi:IMP_TOTAL&gt;220.40&lt;/sanofi:IMP_TOTAL&gt;
///     &lt;sanofi:DISPONIBLE_1&gt;0.00&lt;/sanofi:DISPONIBLE_1&gt;
///     ... DISPONIBLE_2..4
///     &lt;sanofi:CORREO_SANOFI&gt;Paola.Espinoza@sanofi.com&lt;/sanofi:CORREO_SANOFI&gt;
///   &lt;/sanofi:header&gt;
///   &lt;sanofi:details&gt;
///     &lt;sanofi:NUM_LINEA&gt;0001&lt;/sanofi:NUM_LINEA&gt;
///     &lt;sanofi:NUM_ENTRADA&gt;0000000000&lt;/sanofi:NUM_ENTRADA&gt;
///     &lt;sanofi:CUENTA_PUENTE&gt;0000000000&lt;/sanofi:CUENTA_PUENTE&gt;
///     &lt;sanofi:UNIDADES&gt;1.000&lt;/sanofi:UNIDADES&gt;
///     &lt;sanofi:PRECIO_UNITARIO&gt;190.00&lt;/sanofi:PRECIO_UNITARIO&gt;
///     &lt;sanofi:IMPORTE&gt;190.00&lt;/sanofi:IMPORTE&gt;
///     &lt;sanofi:UNIDAD_MEDIDA&gt;Pieza&lt;/sanofi:UNIDAD_MEDIDA&gt;
///     &lt;sanofi:TASA_IVA&gt;0.16&lt;/sanofi:TASA_IVA&gt;
///     &lt;sanofi:IMPORTE_IVA&gt;30.40&lt;/sanofi:IMPORTE_IVA&gt;
///     ... DISPONIBLE_1..6
///   &lt;/sanofi:details&gt;
/// &lt;/sanofi:sanofi&gt;
/// </code>
/// </remarks>
internal static class SanofiAddendaTemplateFactory
{
    private const string NamespaceUri = "https://mexico.sanofi.com/schemas";
    private const string XsiNamespaceUri = "http://www.w3.org/2001/XMLSchema-instance";

    /// <param name="clave">
    /// Clave de <c>catTipoAddenda</c> para este cliente concreto (SANOFI, SANOFI_PASTEUR o
    /// AZTECA_VACUNAS) — ver doc de BD, pendiente #2, sobre por qué se recomienda un registro por
    /// cliente aunque los 3 compartan esta misma estructura de plantilla.
    /// </param>
    /// <param name="numeroProveedor">Valor fijo de <c>NUM_PROVEEDOR</c> para este cliente.</param>
    /// <param name="correoContactoPorDefecto">
    /// Default de <c>CORREO_SANOFI</c> cuando no se capturó <c>CorreoContacto</c> en <c>fccAddenda</c>.
    /// </param>
    public static AddendaTemplateDefinition Crear(string clave, string numeroProveedor, string correoContactoPorDefecto)
    {
        var header = new AddendaNodoDefinicion(
            Nombre: "sanofi:header",
            Campos:
            [
                AddendaCampoDefinicion.Fijo("sanofi:TIPO_DOCTO", "01", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:NUM_ORDEN", ClavesDeCamposDerivados.Factura.NumeroOrdenCompraCliente, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:NUM_PROVEEDOR", numeroProveedor, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:FCTCONV", "1.000", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:MONEDA", ClavesDeCamposDerivados.Factura.Moneda, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:CTA_CORREO", "credito@proquifa.com.mx", FormaSerializacion.Elemento),
                // El PDF exige el nodo siempre presente y vacío/autocerrado — cadena vacía, nunca null.
                AddendaCampoDefinicion.Fijo("sanofi:IMP_RETENCION", string.Empty, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:IMP_TOTAL", ClavesDeCamposDerivados.Factura.Total, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_1", "0.00", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_2", "0.00", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_3", "0.00", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_4", "0.00", FormaSerializacion.Elemento),
                // Único campo genuino de cabecera de todo el análisis (doc de BD, sección 3.4/4).
                AddendaCampoDefinicion.Genuino(
                    "sanofi:CORREO_SANOFI",
                    FormaSerializacion.Elemento,
                    claveGenuina: "CorreoContacto",
                    valorPorDefecto: correoContactoPorDefecto),
            ]);

        var details = new AddendaNodoDefinicion(
            Nombre: "sanofi:details",
            SeRepitePorPartida: true,
            Campos:
            [
                // Mismo concepto que "LineaDeOrden" en los demás formatos (doc de BD, sección 3.4/4).
                AddendaCampoDefinicion.Genuino("sanofi:NUM_LINEA", FormaSerializacion.Elemento, claveGenuina: "LineaDeOrden"),
                AddendaCampoDefinicion.Fijo("sanofi:NUM_ENTRADA", "0000000000", FormaSerializacion.Elemento),
                // Doc de BD, pendiente #3: el PDF dice que siempre es "0000000000", pero las tablas
                // legacy de Sanofi tienen una columna real capturable. Se modela como Genuino con
                // ese default para no perder la capacidad de capturarlo si el pendiente se resuelve
                // a favor de que sí varía — sin ese default, hoy se resuelve exactamente como dice
                // el PDF sin que nadie tenga que capturar nada.
                AddendaCampoDefinicion.Genuino(
                    "sanofi:CUENTA_PUENTE",
                    FormaSerializacion.Elemento,
                    claveGenuina: "CuentaPuente",
                    valorPorDefecto: "0000000000"),
                AddendaCampoDefinicion.Derivado("sanofi:UNIDADES", ClavesDeCamposDerivados.Partida.Cantidad, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:PRECIO_UNITARIO", ClavesDeCamposDerivados.Partida.PrecioUnitario, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:IMPORTE", ClavesDeCamposDerivados.Partida.Importe, FormaSerializacion.Elemento),
                // Doc de BD, pendiente #4: espera el texto que usa Sanofi (p. ej. "Pieza"), no el
                // IdCatUnidad interno — la resolución de ese mapeo de catálogo se asume ya hecha
                // por quien arma InvoiceLineAddendaContextDto.UnitOfMeasureCode, no aquí.
                AddendaCampoDefinicion.Derivado("sanofi:UNIDAD_MEDIDA", ClavesDeCamposDerivados.Partida.UnidadDeMedida, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:TASA_IVA", ClavesDeCamposDerivados.Partida.TasaIva, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Derivado("sanofi:IMPORTE_IVA", ClavesDeCamposDerivados.Partida.MontoIva, FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_1", "0", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_2", "0", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_3", "0", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_4", "0", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_5", "0", FormaSerializacion.Elemento),
                AddendaCampoDefinicion.Fijo("sanofi:DISPONIBLE_6", "0", FormaSerializacion.Elemento),
            ]);

        var raiz = new AddendaNodoDefinicion(
            Nombre: "sanofi:sanofi",
            Campos: [],
            Hijos: [header, details],
            AtributosFijosDeNodo: new Dictionary<string, string>
            {
                // Se declaran ambos namespaces (sanofi y xsi) directo en el nodo raíz de la
                // addenda: al ser un fragmento que Finanzas inserta dentro de un cfdi:Comprobante
                // ya existente, no se puede depender de que "xsi" haya quedado en alcance más
                // arriba — declararlo aquí de nuevo es válido en XML y hace el fragmento
                // autocontenido. Ver IAddendaXmlSerializer.
                ["xmlns:sanofi"] = NamespaceUri,
                ["xmlns:xsi"] = XsiNamespaceUri,
                ["version"] = "1.0",
                ["xsi:schemaLocation"] = $"{NamespaceUri} {NamespaceUri}/sanofi.xsd",
            });

        return new AddendaTemplateDefinition(clave, raiz);
    }
}
