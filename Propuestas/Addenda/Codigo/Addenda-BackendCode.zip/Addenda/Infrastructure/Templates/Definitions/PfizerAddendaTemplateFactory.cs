using Addenda.Domain.Assembly;
using Addenda.Domain.Templates;

namespace Addenda.Infrastructure.Templates.Definitions;

/// <summary>
/// Plantilla del formato Pfizer: <c>Pfizer_Ebox</c> &gt; <c>PfizerPO</c> &gt; N × <c>Lineas</c>, una
/// por partida facturada. Todos los campos se serializan como atributos. Estructura tomada literal
/// de "INFORMACIÓN DE NODOS DE ADENDAS.pdf", páginas 3-4.
/// </summary>
/// <remarks>
/// Ejemplo real del PDF:
/// <code>
/// &lt;Pfizer_Ebox TipoAddenda="1"&gt;
///   &lt;PfizerPO InstruccionesAdicionales="N/A"&gt;
///     &lt;Lineas AMOUNT="209.00" LINE_NO="1" PO_NUMBER="9501315099" QUANTITY="1.0" TAX_CODE="F2"/&gt;
///   &lt;/PfizerPO&gt;
/// &lt;/Pfizer_Ebox&gt;
/// </code>
/// </remarks>
internal static class PfizerAddendaTemplateFactory
{
    private const string Clave = "PFIZER";

    public static AddendaTemplateDefinition Crear()
    {
        var lineas = new AddendaNodoDefinicion(
            Nombre: "Lineas",
            SeRepitePorPartida: true,
            Campos:
            [
                AddendaCampoDefinicion.Derivado("AMOUNT", ClavesDeCamposDerivados.Partida.Importe, FormaSerializacion.Atributo),
                // LINE_NO es el único campo genuino del formato: el mismo concepto que
                // "LineaDeOrden" en fccAddendaPartida (ver doc de BD, sección 3.2).
                AddendaCampoDefinicion.Genuino("LINE_NO", FormaSerializacion.Atributo, claveGenuina: "LineaDeOrden"),
                // PO_NUMBER se repite igual en cada línea — es la particularidad de Pfizer frente
                // a los otros formatos, que lo llevan una sola vez a nivel cabecera.
                AddendaCampoDefinicion.Derivado("PO_NUMBER", ClavesDeCamposDerivados.Partida.NumeroOrdenCompraCliente, FormaSerializacion.Atributo),
                AddendaCampoDefinicion.Derivado("QUANTITY", ClavesDeCamposDerivados.Partida.Cantidad, FormaSerializacion.Atributo),
                // "F1" si la tasa de impuesto de la partida es 0, "F2" en cualquier otro caso. Se
                // cubren varias representaciones textuales de cero porque el motor compara el
                // valor ya formateado como string (ver ryndem-dotnet: el mapeo es sobre texto).
                AddendaCampoDefinicion.Derivado(
                    "TAX_CODE",
                    ClavesDeCamposDerivados.Partida.TasaIva,
                    FormaSerializacion.Atributo,
                    regla: new Dictionary<string, string> { ["0"] = "F1", ["0.0"] = "F1", ["0.00"] = "F1", ["*"] = "F2" }),
            ]);

        var pfizerPo = new AddendaNodoDefinicion(
            Nombre: "PfizerPO",
            Campos: [],
            Hijos: [lineas],
            AtributosFijosDeNodo: new Dictionary<string, string> { ["InstruccionesAdicionales"] = "N/A" });

        var pfizerEbox = new AddendaNodoDefinicion(
            Nombre: "Pfizer_Ebox",
            Campos: [],
            Hijos: [pfizerPo],
            AtributosFijosDeNodo: new Dictionary<string, string> { ["TipoAddenda"] = "1" });

        return new AddendaTemplateDefinition(Clave, pfizerEbox);
    }
}
