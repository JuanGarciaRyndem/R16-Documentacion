using System.Xml.Linq;
using Addenda.Domain.Assembly;
using Addenda.Domain.Interfaces;

namespace Addenda.Infrastructure.Xml;

/// <summary>
/// Convierte el árbol neutral que produce <see cref="AddendaAssembler"/> en el fragmento XML real.
/// Es la única clase de todo el módulo que conoce <c>System.Xml.Linq</c> — el dominio declara el
/// contrato (<see cref="IAddendaXmlSerializer"/>) sin conocer la tecnología concreta.
/// </summary>
/// <remarks>
/// <see cref="AddendaNodoDefinicion.Nombre"/> y <see cref="AddendaCampoDefinicion.NombreCampo"/>
/// pueden traer un prefijo de namespace embebido (p. ej. <c>"sanofi:header"</c>), tal como los
/// declara la plantilla — el dominio no modela namespaces XML, solo texto. Este serializador
/// resuelve esos prefijos así: cualquier atributo del nodo cuyo nombre empiece con <c>"xmlns:"</c>
/// se trata como una declaración de namespace real (no como un atributo de datos) y queda en
/// alcance para ese nodo y sus descendientes; cualquier otro nombre con prefijo se resuelve contra
/// ese alcance, y si el prefijo no fue declarado en ningún ancestro del fragmento, se usa el nombre
/// completo tal cual como nombre local sin namespace (no falla: simplemente no hay nada que
/// resolver, que es el caso de los 3 formatos sin namespace — Mavi, Pfizer, Asofarma).
/// </remarks>
public sealed class AddendaXmlSerializer : IAddendaXmlSerializer
{
    private const string XmlnsPrefix = "xmlns:";

    public string Serializar(AddendaXmlNodo nodoRaiz)
    {
        var elemento = ConstruirElemento(nodoRaiz, new Dictionary<string, XNamespace>());
        return elemento.ToString(SaveOptions.DisableFormatting);
    }

    private static XElement ConstruirElemento(AddendaXmlNodo nodo, IReadOnlyDictionary<string, XNamespace> alcanceHeredado)
    {
        var (declaracionesDeNamespace, atributosDeDatos) = SepararDeclaracionesDeNamespace(nodo.Atributos);

        var alcance = declaracionesDeNamespace.Count == 0
            ? alcanceHeredado
            : Combinar(alcanceHeredado, declaracionesDeNamespace);

        var elemento = new XElement(ResolverNombre(nodo.Nombre, alcance));

        foreach (var (prefijo, ns) in declaracionesDeNamespace)
        {
            elemento.Add(new XAttribute(XNamespace.Xmlns + prefijo, ns.NamespaceName));
        }

        foreach (var (nombreAtributo, valor) in atributosDeDatos)
        {
            elemento.Add(new XAttribute(ResolverNombre(nombreAtributo, alcance), valor));
        }

        if (nodo.Hijos.Count > 0)
        {
            foreach (var hijo in nodo.Hijos)
            {
                elemento.Add(ConstruirElemento(hijo, alcance));
            }
        }
        else if (!string.IsNullOrEmpty(nodo.Valor))
        {
            // Cadena vacía o null (p. ej. sanofi:IMP_RETENCION) se deja sin contenido a propósito:
            // así XElement lo serializa autocerrado, tal como lo exige la plantilla.
            elemento.SetValue(nodo.Valor);
        }

        return elemento;
    }

    private static (List<(string Prefijo, XNamespace Namespace)> Declaraciones, List<(string Nombre, string Valor)> Datos) SepararDeclaracionesDeNamespace(
        IReadOnlyDictionary<string, string> atributos)
    {
        var declaraciones = new List<(string, XNamespace)>();
        var datos = new List<(string, string)>();

        foreach (var (nombre, valor) in atributos)
        {
            if (nombre.StartsWith(XmlnsPrefix, StringComparison.Ordinal))
            {
                declaraciones.Add((nombre[XmlnsPrefix.Length..], XNamespace.Get(valor)));
            }
            else
            {
                datos.Add((nombre, valor));
            }
        }

        return (declaraciones, datos);
    }

    private static Dictionary<string, XNamespace> Combinar(
        IReadOnlyDictionary<string, XNamespace> alcanceHeredado,
        IReadOnlyList<(string Prefijo, XNamespace Namespace)> nuevasDeclaraciones)
    {
        var combinado = new Dictionary<string, XNamespace>(alcanceHeredado);
        foreach (var (prefijo, ns) in nuevasDeclaraciones)
        {
            combinado[prefijo] = ns;
        }

        return combinado;
    }

    private static XName ResolverNombre(string nombre, IReadOnlyDictionary<string, XNamespace> alcance)
    {
        var separador = nombre.IndexOf(':');
        if (separador < 0)
        {
            return XName.Get(nombre);
        }

        var prefijo = nombre[..separador];
        var nombreLocal = nombre[(separador + 1)..];

        return alcance.TryGetValue(prefijo, out var ns)
            ? ns + nombreLocal
            : XName.Get(nombre);
    }
}
