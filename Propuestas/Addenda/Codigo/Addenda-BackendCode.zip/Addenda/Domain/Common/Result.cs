using Addenda.Domain.Errors;

namespace Addenda.Domain.Common;

/// <summary>
/// Resultado de una operación que puede fallar de forma esperada.
/// Un flujo esperado (validación, regla de negocio, recurso no encontrado) se modela con
/// <see cref="Result"/>, nunca con una excepción. Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
public class Result
{
    protected Result(bool isSuccess, IReadOnlyList<ErrorDefinition> errors)
    {
        IsSuccess = isSuccess;
        Errors = errors;
    }

    public bool IsSuccess { get; }

    public bool IsFailure => !IsSuccess;

    public IReadOnlyList<ErrorDefinition> Errors { get; }

    /// <summary>
    /// El dominio y la infraestructura fallan con exactamente un error (fail-fast).
    /// </summary>
    public ErrorDefinition Error => Errors[0];

    public static Result Ok() => new(true, []);

    public static Result Fail(ErrorDefinition error) => new(false, [error]);

    /// <summary>
    /// Único consumidor legítimo: la validación de entrada en la capa de aplicación, que sí
    /// produce una lista de errores (uno por campo). El dominio y la infraestructura usan la
    /// sobrecarga con un solo <see cref="ErrorDefinition"/>.
    /// </summary>
    internal static Result Fail(IReadOnlyList<ErrorDefinition> errors) => new(false, errors);

    public static Result<T> Ok<T>(T value) => new(value, true, []);

    public static Result<T> Fail<T>(ErrorDefinition error) => new(default, false, [error]);

    internal static Result<T> Fail<T>(IReadOnlyList<ErrorDefinition> errors) => new(default, false, errors);
}

/// <summary>
/// Variante de <see cref="Result"/> que además transporta el valor producido por la operación
/// cuando esta tiene éxito.
/// </summary>
public sealed class Result<T> : Result
{
    internal Result(T? value, bool isSuccess, IReadOnlyList<ErrorDefinition> errors)
        : base(isSuccess, errors)
    {
        _value = value;
    }

    private readonly T? _value;

    /// <summary>
    /// Lanza si se consulta sobre un resultado fallido: el valor solo existe cuando
    /// <see cref="Result.IsSuccess"/> es verdadero.
    /// </summary>
    public T Value => IsSuccess
        ? _value!
        : throw new InvalidOperationException("No se puede leer el valor de un Result fallido.");
}
