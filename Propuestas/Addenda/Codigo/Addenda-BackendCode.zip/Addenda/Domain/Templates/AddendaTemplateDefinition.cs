namespace Addenda.Domain.Templates;

/// <summary>
/// Plantilla completa de un formato de addenda: qué forma tiene el nodo raíz que va dentro de
/// <c>cfdi:Addenda</c> para un cliente dado. Corresponde una a una con una fila de
/// <c>catTipoAddenda</c> (ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5).
/// </summary>
/// <param name="ClaveTipoAddenda">La Clave del catálogo (MAVI, PFIZER, ASOFARMA, SANOFI).</param>
/// <param name="NodoRaiz">El nodo que se inserta directo bajo <c>cfdi:Addenda</c>.</param>
public sealed record AddendaTemplateDefinition(string ClaveTipoAddenda, AddendaNodoDefinicion NodoRaiz);
