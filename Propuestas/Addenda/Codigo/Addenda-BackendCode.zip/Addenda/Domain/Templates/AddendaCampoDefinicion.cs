namespace Addenda.Domain.Templates;

/// <summary>
/// Definición declarativa de un campo dentro de un nodo de la plantilla de un cliente. El motor de
/// ensamblado (<see cref="Assembly.AddendaAssembler"/>) interpreta esta definición sin conocer al
/// cliente concreto — la única parte específica de cada cliente es la data, no el código.
/// </summary>
/// <param name="NombreCampo">Nombre del atributo o elemento en el XML final (p. ej. "LINE_NO").</param>
/// <param name="Origen">De dónde sale el valor. Ver <see cref="OrigenCampoAddenda"/>.</param>
/// <param name="FormaSerializacion">Si se serializa como atributo o como elemento hijo.</param>
/// <param name="ValorFijo">Requerido cuando <paramref name="Origen"/> es <see cref="OrigenCampoAddenda.Fijo"/>.</param>
/// <param name="NombreOrigen">
/// Requerido cuando <paramref name="Origen"/> es <see cref="OrigenCampoAddenda.Derivado"/>: la clave
/// del campo dentro del contexto de factura o de partida que entrega la capa de aplicación.
/// </param>
/// <param name="ClaveGenuina">
/// Solo para <see cref="OrigenCampoAddenda.Genuino"/>: la Clave a buscar en fccAddenda/fccAddendaPartida.
/// Si es null, se usa <paramref name="NombreCampo"/> como Clave.
/// </param>
/// <param name="ValorPorDefecto">
/// Solo para <see cref="OrigenCampoAddenda.Genuino"/>: valor a usar si no se capturó. Si es null y el
/// valor no existe, el campo es obligatorio y su ausencia hace fallar el ensamblado (y, con ello, la
/// validación previa al timbrado).
/// </param>
/// <param name="Regla">
/// Mapeo condicional opcional aplicado sobre el valor ya resuelto (p. ej. tasa de IVA → TAX_CODE).
/// La clave <c>"*"</c> es el valor por default del mapeo cuando ningún otro caso coincide.
/// </param>
public sealed record AddendaCampoDefinicion(
    string NombreCampo,
    OrigenCampoAddenda Origen,
    FormaSerializacion FormaSerializacion,
    string? ValorFijo = null,
    string? NombreOrigen = null,
    string? ClaveGenuina = null,
    string? ValorPorDefecto = null,
    IReadOnlyDictionary<string, string>? Regla = null)
{
    public static AddendaCampoDefinicion Fijo(string nombreCampo, string valor, FormaSerializacion forma) =>
        new(nombreCampo, OrigenCampoAddenda.Fijo, forma, ValorFijo: valor);

    public static AddendaCampoDefinicion Derivado(
        string nombreCampo,
        string nombreOrigen,
        FormaSerializacion forma,
        IReadOnlyDictionary<string, string>? regla = null) =>
        new(nombreCampo, OrigenCampoAddenda.Derivado, forma, NombreOrigen: nombreOrigen, Regla: regla);

    public static AddendaCampoDefinicion Genuino(
        string nombreCampo,
        FormaSerializacion forma,
        string? claveGenuina = null,
        string? valorPorDefecto = null) =>
        new(nombreCampo, OrigenCampoAddenda.Genuino, forma, ClaveGenuina: claveGenuina, ValorPorDefecto: valorPorDefecto);
}
