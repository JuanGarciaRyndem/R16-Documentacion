namespace Addenda.Domain.Templates;

/// <summary>
/// De dónde sale el valor de un campo de la plantilla de un cliente. Es la clasificación central
/// del análisis: la mayoría de los campos que exigen los formatos de addenda son <see cref="Fijo"/>
/// o <see cref="Derivado"/> — muy pocos son <see cref="Genuino"/> (datos que solo existen para la
/// addenda). Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", secciones 2 a 4.
/// </summary>
public enum OrigenCampoAddenda
{
    /// <summary>Constante propia del formato del cliente. No cambia entre transacciones.</summary>
    Fijo,

    /// <summary>
    /// Ya existe en los datos de la factura o de la partida (fccFactura/fccFacturaPartida en el
    /// sistema real). El motor lo toma del contexto que se le entrega, no de una tabla de addenda.
    /// </summary>
    Derivado,

    /// <summary>
    /// No existe en ningún otro lado: requiere una fila en fccAddenda o fccAddendaPartida.
    /// Puede tener un valor por default para cuando no se capturó.
    /// </summary>
    Genuino,
}
