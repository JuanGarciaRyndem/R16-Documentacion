namespace Addenda.Domain.Templates;

/// <summary>
/// Cómo se serializa un campo dentro de su nodo XML. Pfizer y Asofarma usan atributos; Mavi y
/// Sanofi usan elementos hijos — el motor debe soportar ambas formas sin código distinto por
/// cliente. Ver "INFORMACIÓN DE NODOS DE ADENDAS.pdf".
/// </summary>
public enum FormaSerializacion
{
    Atributo,
    Elemento,
}
