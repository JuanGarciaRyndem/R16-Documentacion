namespace Addenda.Domain.Templates;

/// <summary>
/// Definición declarativa de un nodo XML dentro de la plantilla de un cliente. Un árbol de estos
/// nodos describe formatos tan distintos como Mavi (un solo nodo de cabecera, sin detalle) y Sanofi
/// (un nodo con namespace, un hijo de cabecera y un hijo que se repite por partida) con el mismo
/// modelo — la variación es de datos, no de código.
/// </summary>
/// <param name="Nombre">Nombre del nodo XML, con prefijo de namespace si aplica (p. ej. "sanofi:header").</param>
/// <param name="Campos">Campos propios de este nodo. Ver <see cref="AddendaCampoDefinicion"/>.</param>
/// <param name="Hijos">Nodos hijos, en el orden en que deben aparecer en el XML.</param>
/// <param name="AtributosFijosDeNodo">
/// Atributos siempre constantes de este nodo (típicamente declaraciones de namespace). A diferencia
/// de un <see cref="AddendaCampoDefinicion"/> fijo, estos nunca varían de forma de serialización:
/// siempre son atributos del nodo.
/// </param>
/// <param name="SeRepitePorPartida">
/// Si es verdadero, este nodo se genera una vez por cada partida de la factura, usando el contexto
/// de esa partida en lugar del contexto de cabecera para resolver sus campos <see cref="OrigenCampoAddenda.Derivado"/>
/// y <see cref="OrigenCampoAddenda.Genuino"/>.
/// </param>
public sealed record AddendaNodoDefinicion(
    string Nombre,
    IReadOnlyList<AddendaCampoDefinicion> Campos,
    IReadOnlyList<AddendaNodoDefinicion>? Hijos = null,
    IReadOnlyDictionary<string, string>? AtributosFijosDeNodo = null,
    bool SeRepitePorPartida = false);
