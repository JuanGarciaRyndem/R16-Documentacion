using Addenda.Domain.Entities;

namespace Addenda.Domain.Interfaces;

/// <summary>
/// Contrato de acceso a los valores genéricos de addenda (fccAddenda / fccAddendaPartida). El
/// dominio declara qué necesita; la implementación concreta (Entity Framework) vive en
/// Infrastructure. Ver ryndem-dotnet/02-architecture-and-layers.
/// </summary>
public interface IAddendaRepository
{
    Task<IReadOnlyList<AddendaCabecera>> ObtenerCabeceraPorPedidoAsync(Guid idTPPedido, CancellationToken cancellationToken);

    Task<IReadOnlyList<AddendaDetalle>> ObtenerDetallePorPartidasAsync(
        IReadOnlyList<Guid> idsTPPartidaPedido,
        CancellationToken cancellationToken);

    Task AgregarCabeceraAsync(AddendaCabecera valor, CancellationToken cancellationToken);

    Task AgregarDetalleAsync(AddendaDetalle valor, CancellationToken cancellationToken);
}
