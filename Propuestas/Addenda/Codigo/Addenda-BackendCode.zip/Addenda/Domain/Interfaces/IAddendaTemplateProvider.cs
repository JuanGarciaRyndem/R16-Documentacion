using Addenda.Domain.Templates;

namespace Addenda.Domain.Interfaces;

/// <summary>
/// Contrato para obtener la plantilla de un cliente por la Clave de su <c>catTipoAddenda</c>. La
/// implementación (Infrastructure) es donde vive el detalle de cada cliente — el dominio y la
/// aplicación solo piden la plantilla, nunca conocen cómo se construyó.
/// Ver "[PROPUESTA] Adenda de Factura - Impacto en Backend.md", sección 5.2.
/// </summary>
public interface IAddendaTemplateProvider
{
    /// <summary>Null si no existe una plantilla registrada para esa Clave.</summary>
    AddendaTemplateDefinition? ObtenerPlantilla(string claveTipoAddenda);
}
