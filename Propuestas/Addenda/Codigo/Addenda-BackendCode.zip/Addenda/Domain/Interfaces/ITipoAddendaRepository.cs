using Addenda.Domain.Entities;

namespace Addenda.Domain.Interfaces;

/// <summary>Contrato de acceso al catálogo de formatos de addenda (catTipoAddenda).</summary>
public interface ITipoAddendaRepository
{
    Task<TipoAddenda?> ObtenerPorIdAsync(Guid idCatTipoAddenda, CancellationToken cancellationToken);

    Task<TipoAddenda?> ObtenerPorClaveAsync(string clave, CancellationToken cancellationToken);
}
