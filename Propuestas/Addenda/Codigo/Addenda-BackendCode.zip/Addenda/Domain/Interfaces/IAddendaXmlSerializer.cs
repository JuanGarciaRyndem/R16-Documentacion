using Addenda.Domain.Assembly;

namespace Addenda.Domain.Interfaces;

/// <summary>
/// Contrato para convertir el árbol neutral que produce <see cref="AddendaAssembler"/> en el
/// fragmento XML real que se inserta dentro de <c>cfdi:Addenda</c>. La implementación usa
/// <c>System.Xml.Linq</c> en Infrastructure — el dominio no depende de ninguna tecnología XML.
/// </summary>
public interface IAddendaXmlSerializer
{
    /// <summary>Serializa el nodo raíz de la plantilla ya resuelto, sin el contenedor <c>cfdi:Addenda</c>.</summary>
    string Serializar(AddendaXmlNodo nodoRaiz);
}
