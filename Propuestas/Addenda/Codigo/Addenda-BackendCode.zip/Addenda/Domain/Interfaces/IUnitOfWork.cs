namespace Addenda.Domain.Interfaces;

/// <summary>
/// Confirma como un todo una operación de negocio que toca varias entidades. Guardar la cabecera y
/// el detalle de una addenda (tarea BE-8) es exactamente ese caso: si falla a mitad, no debe quedar
/// una cabecera sin su detalle o viceversa. Ver ryndem-dotnet/02-architecture-and-layers.
/// </summary>
public interface IUnitOfWork
{
    Task<int> GuardarCambiosAsync(CancellationToken cancellationToken);
}
