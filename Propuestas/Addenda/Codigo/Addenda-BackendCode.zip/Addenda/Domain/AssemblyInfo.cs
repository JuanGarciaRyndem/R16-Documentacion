using System.Runtime.CompilerServices;

// El contrato asimétrico de Result: "Fail" con una lista de errores es internal, y su único
// consumidor legítimo es la validación de entrada en Application. Se fuerza por visibilidad, no
// por disciplina — ver ryndem-dotnet/05-errors-and-resilience. Testing la necesita para probar el
// propio contrato.
[assembly: InternalsVisibleTo("Addenda.Application")]
[assembly: InternalsVisibleTo("Addenda.Testing")]
