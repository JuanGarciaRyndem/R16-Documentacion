namespace Addenda.Domain.Entities;

/// <summary>
/// Catálogo de formatos de addenda soportados (<c>catTipoAddenda</c>). Identifica el formato de
/// un cliente y si tiene nivel de detalle por partida o requiere correo de contacto — lo que le
/// permite a pqf y al motor de ensamblado decidir sin adivinar.
/// Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.
/// </summary>
public class TipoAddenda
{
    public Guid IdCatTipoAddenda { get; set; }

    /// <summary>Clave corta del formato: MAVI, PFIZER, ASOFARMA, SANOFI.</summary>
    public required string Clave { get; set; }

    public required string Descripcion { get; set; }

    /// <summary>Si el formato repite un bloque de detalle una vez por partida.</summary>
    public bool TieneDetallePorPartida { get; set; }

    /// <summary>Si el formato exige un correo de contacto a nivel de pedido (con default).</summary>
    public bool RequiereCorreoContacto { get; set; }

    public bool Activo { get; set; } = true;
}
