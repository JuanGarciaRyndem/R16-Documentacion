namespace Addenda.Domain.Entities;

/// <summary>
/// Valor genérico de addenda a nivel partida (<c>fccAddendaPartida</c>). No depende de
/// <see cref="AddendaCabecera"/> — está anclada directo a la partida y al catálogo, porque una
/// partida puede existir sin que haya valores de cabecera para ese pedido (ver Mavi, que no usa
/// esta tabla en absoluto por no tener nivel de detalle).
/// Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.
/// </summary>
public class AddendaDetalle
{
    public Guid IdFccAddendaPartida { get; set; }

    /// <summary>La partida origen (tpPartidaPedido) a la que pertenece este valor.</summary>
    public required Guid IdTPPartidaPedido { get; set; }

    public required Guid IdCatTipoAddenda { get; set; }

    /// <summary>Nombre del campo tal como lo espera la plantilla del cliente (p. ej. "LineaDeOrden").</summary>
    public required string Clave { get; set; }

    /// <summary>El valor de ese campo para esa partida.</summary>
    public required string Valor { get; set; }

    public DateTime FechaRegistro { get; set; }

    public DateTime FechaUltimaActualizacion { get; set; }
}
