namespace Addenda.Domain.Entities;

/// <summary>
/// Valor genérico de addenda a nivel pedido (<c>fccAddenda</c>). Un pedido puede tener varias
/// filas — una por <see cref="Clave"/> — porque el modelo guarda pares Clave/Valor atómicos y
/// agnósticos al cliente en lugar de columnas específicas.
/// Ver "[PROPUESTA] Adenda de Factura - Impacto en BD.md", sección 5.
/// </summary>
public class AddendaCabecera
{
    public Guid IdFccAddenda { get; set; }

    /// <summary>El pedido origen (tpPedido) al que pertenece este valor.</summary>
    public required Guid IdTPPedido { get; set; }

    public required Guid IdCatTipoAddenda { get; set; }

    /// <summary>Nombre del campo tal como lo espera la plantilla del cliente (p. ej. "CorreoContacto").</summary>
    public required string Clave { get; set; }

    /// <summary>El valor de ese campo, ya listo para insertarse en el XML.</summary>
    public required string Valor { get; set; }

    public DateTime? FechaGeneracion { get; set; }

    public DateTime FechaRegistro { get; set; }

    public DateTime FechaUltimaActualizacion { get; set; }
}
