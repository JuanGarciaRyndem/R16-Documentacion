namespace Addenda.Domain.Errors;

/// <summary>
/// Única base para un flujo inesperado (base de datos caída, timeout, bug). No hay jerarquía de
/// excepciones por capa: la semántica viaja en <see cref="Error"/>, no en el tipo.
/// Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
public sealed class SemanticException : Exception
{
    public SemanticException(ErrorDefinition error)
        : base(error.Description)
    {
        Error = error;
    }

    public SemanticException(ErrorDefinition error, Exception innerException)
        : base(error.Description, innerException)
    {
        Error = error;
    }

    public ErrorDefinition Error { get; }
}
