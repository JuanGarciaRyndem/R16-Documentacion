namespace Addenda.Domain.Errors;

/// <summary>
/// Entrada del catálogo de errores. Todo error nace de aquí: el código y su clasificación nunca
/// se declaran en línea en el sitio del <c>throw</c> o del <c>Result.Fail</c>.
/// Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
/// <param name="Code">Identificador único, auditable y reportable (p. ej. <c>ADD-001</c>).</param>
/// <param name="Title">Título breve dirigido al consumidor del API. En inglés: viaja en la respuesta.</param>
/// <param name="Description">Mensaje técnico interno, en español. Nunca se devuelve al consumidor.</param>
/// <param name="Category">Clasificación semántica. Determina el estado HTTP.</param>
/// <param name="Severity">Impacto operativo. Determina el nivel de log.</param>
/// <param name="HttpStatusCode">Estado HTTP autoritativo de la respuesta.</param>
/// <param name="IsTransient">Si se puede resolver reintentando.</param>
public sealed record ErrorDefinition(
    string Code,
    string Title,
    string Description,
    ErrorCategory Category,
    ErrorSeverity Severity,
    int HttpStatusCode,
    bool IsTransient = false);
