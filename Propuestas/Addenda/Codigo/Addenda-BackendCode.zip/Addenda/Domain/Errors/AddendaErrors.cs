namespace Addenda.Domain.Errors;

/// <summary>
/// Catálogo de errores del dominio de Addenda. Todo <see cref="Result.Fail"/> o
/// <see cref="SemanticException"/> de este servicio referencia una entrada de aquí — nunca un
/// código declarado en línea. Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
/// <remarks>
/// Prefijo <c>ADD</c> — dominio de negocio de Addenda de Factura. Se agrega en el mismo PR que
/// introduce el primer código que lo usa (este mismo cambio), junto con los prefijos comunes
/// <c>VAL</c> y <c>UNX</c> que ya trae el estándar.
/// </remarks>
public static class AddendaErrors
{
    public static class Validacion
    {
        /// <summary>
        /// Un solo código para toda la validación de entrada. El detalle por campo viaja en el
        /// <c>Title</c> y la <c>Description</c> de cada instancia, derivada con <c>with</c>.
        /// </summary>
        public static readonly ErrorDefinition FalloDeValidacion = new(
            Code: "VAL-001",
            Title: "Validation failed",
            Description: "La solicitud no cumple las reglas de validación de entrada.",
            Category: ErrorCategory.Validation,
            Severity: ErrorSeverity.Low,
            HttpStatusCode: 400);
    }

    public static class TipoAddenda
    {
        public static readonly ErrorDefinition NoEncontradoOInactivo = new(
            Code: "ADD-001",
            Title: "Addenda type not found",
            Description: "El IdCatTipoAddenda indicado no existe en el catálogo o está inactivo.",
            Category: ErrorCategory.Resource,
            Severity: ErrorSeverity.Low,
            HttpStatusCode: 404);
    }

    public static class Cabecera
    {
        public static readonly ErrorDefinition ClienteSinAddendaHabilitada = new(
            Code: "ADD-002",
            Title: "Client is not enabled for addenda",
            Description: "Se recibieron valores de addenda para un pedido cuyo cliente no tiene addenda habilitada.",
            Category: ErrorCategory.Business,
            Severity: ErrorSeverity.Medium,
            HttpStatusCode: 422);

        public static readonly ErrorDefinition FaltaValorObligatorio = new(
            Code: "ADD-003",
            Title: "Required addenda value is missing",
            Description: "La plantilla del cliente exige un valor de cabecera que no tiene default y no fue capturado.",
            Category: ErrorCategory.Business,
            Severity: ErrorSeverity.Medium,
            HttpStatusCode: 422);
    }

    public static class Partida
    {
        public static readonly ErrorDefinition FaltaValorObligatorio = new(
            Code: "ADD-004",
            Title: "Required addenda value is missing for a line item",
            Description: "La plantilla del cliente exige un valor de detalle que no tiene default y no fue capturado para una partida.",
            Category: ErrorCategory.Business,
            Severity: ErrorSeverity.Medium,
            HttpStatusCode: 422);
    }

    public static class Ensamblado
    {
        public static readonly ErrorDefinition DatosDeFacturaNoEncontrados = new(
            Code: "ADD-005",
            Title: "Invoice data not found for addenda assembly",
            Description: "No se encontraron los datos de factura/partida necesarios para ensamblar la addenda del pedido indicado.",
            Category: ErrorCategory.Resource,
            Severity: ErrorSeverity.Low,
            HttpStatusCode: 404);

        public static readonly ErrorDefinition ValorSinMapeoEnRegla = new(
            Code: "ADD-006",
            Title: "Addenda template rule has no mapping for the resolved value",
            Description: "La regla condicional de un campo de la plantilla no define un mapeo para el valor resuelto, ni tiene un valor por default (\"*\"). Es un problema de configuración de la plantilla, no de los datos de la factura.",
            Category: ErrorCategory.Business,
            Severity: ErrorSeverity.Medium,
            HttpStatusCode: 422);
    }

    public static class Infraestructura
    {
        public static readonly ErrorDefinition NoDisponible = new(
            Code: "INF-001",
            Title: "Data store unavailable",
            Description: "La base de datos de Addenda no respondió dentro del tiempo esperado.",
            Category: ErrorCategory.Infrastructure,
            Severity: ErrorSeverity.Critical,
            HttpStatusCode: 503,
            IsTransient: true);
    }

    public static class Generico
    {
        public static readonly ErrorDefinition NoClasificado = new(
            Code: "UNX-001",
            Title: "Unexpected error",
            Description: "Ocurrió un error no clasificado. Ver el correlationId en el registro para el detalle.",
            Category: ErrorCategory.Unexpected,
            Severity: ErrorSeverity.High,
            HttpStatusCode: 500);
    }

    /// <summary>
    /// Todas las entradas del catálogo. Lo consume <c>ErrorCatalogTests</c> para garantizar por
    /// prueba que ningún código se repite. Ver ryndem-dotnet/09-testing.
    /// </summary>
    public static IReadOnlyList<ErrorDefinition> Todos =>
    [
        Validacion.FalloDeValidacion,
        TipoAddenda.NoEncontradoOInactivo,
        Cabecera.ClienteSinAddendaHabilitada,
        Cabecera.FaltaValorObligatorio,
        Partida.FaltaValorObligatorio,
        Ensamblado.DatosDeFacturaNoEncontrados,
        Ensamblado.ValorSinMapeoEnRegla,
        Infraestructura.NoDisponible,
        Generico.NoClasificado,
    ];
}
