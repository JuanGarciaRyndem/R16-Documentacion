namespace Addenda.Domain.Errors;

/// <summary>
/// Clasificación semántica de un <see cref="ErrorDefinition"/>. Determina el estado HTTP
/// autoritativo y si el error es reintentable. Ver ryndem-dotnet/05-errors-and-resilience.
/// </summary>
public enum ErrorCategory
{
    Validation,
    Business,
    Resource,
    Security,
    Integration,
    Infrastructure,
    Unexpected,
}
