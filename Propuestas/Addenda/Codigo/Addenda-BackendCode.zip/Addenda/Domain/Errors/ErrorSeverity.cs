namespace Addenda.Domain.Errors;

/// <summary>
/// Impacto operativo de un <see cref="ErrorDefinition"/>. Determina el nivel de log: deja de ser
/// criterio individual de cada desarrollador y se deriva del catálogo.
/// </summary>
public enum ErrorSeverity
{
    Low,
    Medium,
    High,
    Critical,
}
