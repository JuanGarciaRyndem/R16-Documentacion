using Addenda.Domain.Common;
using Addenda.Domain.Errors;
using Addenda.Domain.Templates;

namespace Addenda.Domain.Assembly;

/// <summary>
/// El motor genérico de ensamblado de addenda. Interpreta una <see cref="AddendaTemplateDefinition"/>
/// sin conocer al cliente concreto: resuelve cada campo según su origen (fijo, derivado o genuino),
/// repite el nodo de detalle una vez por partida y produce un árbol neutral
/// (<see cref="AddendaXmlNodo"/>) listo para que la infraestructura lo serialice.
/// Ver "[PROPUESTA] Adenda de Factura - Impacto en Backend.md", sección 5.
/// </summary>
/// <remarks>
/// Es un servicio de dominio sin estado: no requiere inyección de dependencias ni ciclo de vida, y
/// por eso es estático. La misma validación de completitud que exige la tarea BE-7 del catálogo de
/// tareas no es un paso aparte: es lo que hace fallar a <see cref="Ensamblar"/> cuando falta un
/// valor genuino obligatorio sin default — <see cref="Validar"/> solo expone esa comprobación sin
/// devolver el árbol.
/// </remarks>
public static class AddendaAssembler
{
    public static Result<AddendaXmlNodo> Ensamblar(AddendaTemplateDefinition plantilla, FacturaAddendaContexto contexto) =>
        ResolverNodo(plantilla.NodoRaiz, contexto, partidaActual: null);

    /// <summary>
    /// Validación previa al timbrado (tarea BE-7): recorre la plantilla igual que
    /// <see cref="Ensamblar"/>, pero descarta el árbol resultante. Falla con el mismo código que
    /// fallaría el ensamblado real, para que el mensaje de rechazo identifique el dato faltante
    /// antes de intentar generar el XML.
    /// </summary>
    public static Result Validar(AddendaTemplateDefinition plantilla, FacturaAddendaContexto contexto)
    {
        var resultado = Ensamblar(plantilla, contexto);
        return resultado.IsSuccess ? Result.Ok() : Result.Fail(resultado.Error);
    }

    private static Result<AddendaXmlNodo> ResolverNodo(
        AddendaNodoDefinicion nodoDef,
        FacturaAddendaContexto factura,
        PartidaAddendaContexto? partidaActual)
    {
        var atributos = nodoDef.AtributosFijosDeNodo is null
            ? new Dictionary<string, string>()
            : new Dictionary<string, string>(nodoDef.AtributosFijosDeNodo);

        var hijosResultantes = new List<AddendaXmlNodo>();

        foreach (var campo in nodoDef.Campos)
        {
            var valorResuelto = ResolverCampo(campo, factura, partidaActual);
            if (valorResuelto.IsFailure)
            {
                return Result.Fail<AddendaXmlNodo>(valorResuelto.Error);
            }

            if (campo.FormaSerializacion == FormaSerializacion.Atributo)
            {
                atributos[campo.NombreCampo] = valorResuelto.Value;
            }
            else
            {
                hijosResultantes.Add(new AddendaXmlNodo { Nombre = campo.NombreCampo, Valor = valorResuelto.Value });
            }
        }

        foreach (var hijoDef in nodoDef.Hijos ?? [])
        {
            if (hijoDef.SeRepitePorPartida)
            {
                foreach (var partida in factura.Partidas)
                {
                    var resultadoHijo = ResolverNodo(hijoDef, factura, partida);
                    if (resultadoHijo.IsFailure)
                    {
                        return Result.Fail<AddendaXmlNodo>(resultadoHijo.Error);
                    }

                    hijosResultantes.Add(resultadoHijo.Value);
                }
            }
            else
            {
                var resultadoHijo = ResolverNodo(hijoDef, factura, partidaActual);
                if (resultadoHijo.IsFailure)
                {
                    return Result.Fail<AddendaXmlNodo>(resultadoHijo.Error);
                }

                hijosResultantes.Add(resultadoHijo.Value);
            }
        }

        return Result.Ok(new AddendaXmlNodo
        {
            Nombre = nodoDef.Nombre,
            Atributos = atributos,
            Hijos = hijosResultantes,
        });
    }

    private static Result<string> ResolverCampo(
        AddendaCampoDefinicion campo,
        FacturaAddendaContexto factura,
        PartidaAddendaContexto? partidaActual)
    {
        string valorBase;

        switch (campo.Origen)
        {
            case OrigenCampoAddenda.Fijo:
                // Invariante de configuración: una plantilla mal armada sin ValorFijo en un campo
                // Fijo es un error de programación, no un flujo de negocio — por eso lanza en vez
                // de devolver Result.Fail.
                valorBase = campo.ValorFijo
                    ?? throw new InvalidOperationException(
                        $"El campo '{campo.NombreCampo}' está declarado como Fijo pero no tiene ValorFijo.");
                break;

            case OrigenCampoAddenda.Derivado:
                var camposDerivados = partidaActual?.CamposDerivados ?? factura.CamposDerivados;
                if (campo.NombreOrigen is null || !camposDerivados.TryGetValue(campo.NombreOrigen, out var derivado))
                {
                    return Result.Fail<string>(AddendaErrors.Ensamblado.DatosDeFacturaNoEncontrados);
                }

                valorBase = derivado;
                break;

            case OrigenCampoAddenda.Genuino:
                var claveGenuina = campo.ClaveGenuina ?? campo.NombreCampo;
                var valoresGenuinos = partidaActual?.ValoresGenuinos ?? factura.ValoresGenuinos;
                if (valoresGenuinos.TryGetValue(claveGenuina, out var capturado))
                {
                    valorBase = capturado;
                }
                else if (campo.ValorPorDefecto is not null)
                {
                    valorBase = campo.ValorPorDefecto;
                }
                else
                {
                    // Es exactamente el hallazgo obligatorio-sin-default que valida BE-7: falta un
                    // dato genuino que la plantilla del cliente exige y que nadie capturó.
                    var errorFaltante = partidaActual is not null
                        ? AddendaErrors.Partida.FaltaValorObligatorio
                        : AddendaErrors.Cabecera.FaltaValorObligatorio;
                    return Result.Fail<string>(errorFaltante);
                }

                break;

            default:
                throw new ArgumentOutOfRangeException(nameof(campo), campo.Origen, "Origen de campo de addenda no reconocido.");
        }

        if (campo.Regla is not null)
        {
            if (campo.Regla.TryGetValue(valorBase, out var mapeado))
            {
                return Result.Ok(mapeado);
            }

            if (campo.Regla.TryGetValue("*", out var porDefecto))
            {
                return Result.Ok(porDefecto);
            }

            return Result.Fail<string>(AddendaErrors.Ensamblado.ValorSinMapeoEnRegla);
        }

        return Result.Ok(valorBase);
    }
}
