namespace Addenda.Domain.Assembly;

/// <summary>
/// Datos de una partida facturada que el motor necesita para resolver un nodo de detalle
/// (<c>SeRepitePorPartida = true</c>). Lo arma la capa de aplicación a partir de
/// <c>fccFacturaPartida</c> y de <c>fccAddendaPartida</c> — el dominio no conoce esas tablas, solo
/// recibe los valores ya resueltos.
/// </summary>
/// <param name="IdTPPartidaPedido">La partida origen.</param>
/// <param name="CamposDerivados">
/// Valores que ya existen en la partida facturada (importe, cantidad, unidad de medida, tasa de
/// IVA...), indexados por el <c>NombreOrigen</c> que declara la plantilla.
/// </param>
/// <param name="ValoresGenuinos">
/// Valores capturados específicamente para addenda en <c>fccAddendaPartida</c> para esta partida
/// (p. ej. "LineaDeOrden"), indexados por <c>Clave</c>.
/// </param>
public sealed record PartidaAddendaContexto(
    Guid IdTPPartidaPedido,
    IReadOnlyDictionary<string, string> CamposDerivados,
    IReadOnlyDictionary<string, string> ValoresGenuinos);
