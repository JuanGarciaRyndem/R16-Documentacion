namespace Addenda.Domain.Assembly;

/// <summary>
/// Nombres de los campos derivados que las plantillas pueden referenciar en un
/// <c>AddendaCampoDefinicion.Derivado(nombreOrigen, ...)</c>. Es el vocabulario compartido entre
/// quien arma el <see cref="FacturaAddendaContexto"/> (Application, a partir de la factura real) y
/// quien define las plantillas (Infrastructure, una por cliente) — evita que ambos lados dupliquen
/// el mismo texto suelto y que un error de tipeo en un lado quede sin detectar hasta producción.
/// </summary>
public static class ClavesDeCamposDerivados
{
    public static class Factura
    {
        public const string RfcEmisor = "RfcEmisor";
        public const string EmpresaEmisora = "EmpresaEmisora";
        public const string FechaFacturacion = "FechaFacturacion";
        public const string NumeroOrdenCompraCliente = "NumeroOrdenCompraCliente";
        public const string Moneda = "Moneda";
        public const string Total = "Total";
        public const string MontoIva = "MontoIva";
        public const string TasaIva = "TasaIva";
        public const string NumeroFactura = "NumeroFactura";
        public const string Folio = "Folio";
        public const string TipoComprobante = "TipoComprobante";
    }

    public static class Partida
    {
        public const string Importe = "Importe";
        public const string Cantidad = "Cantidad";
        public const string PrecioUnitario = "PrecioUnitario";
        public const string UnidadDeMedida = "UnidadDeMedida";
        public const string TasaIva = "TasaIva";
        public const string MontoIva = "MontoIva";
        public const string ImporteImpuestoTrasladado = "ImporteImpuestoTrasladado";

        /// <summary>Se repite igual en cada partida: es lo que exige el formato Pfizer.</summary>
        public const string NumeroOrdenCompraCliente = "NumeroOrdenCompraCliente";
    }
}
