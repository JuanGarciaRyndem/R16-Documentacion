namespace Addenda.Domain.Assembly;

/// <summary>
/// Datos de la factura y sus partidas que el motor de ensamblado necesita para armar la addenda de
/// un pedido. Lo arma la capa de aplicación a partir de <c>fccFactura</c>, <c>fccFacturaPartida</c>,
/// <c>fccAddenda</c> y <c>fccAddendaPartida</c> — el dominio solo ve valores ya resueltos, nunca
/// accede a esas tablas directamente.
/// </summary>
/// <param name="IdTPPedido">El pedido facturado.</param>
/// <param name="CamposDerivados">
/// Valores de cabecera que ya existen en la factura (moneda, folio, serie, total, IVA, RFC
/// emisor...), indexados por el <c>NombreOrigen</c> que declara la plantilla.
/// </param>
/// <param name="ValoresGenuinos">
/// Valores de cabecera capturados específicamente para addenda en <c>fccAddenda</c> (p. ej.
/// "CorreoContacto"), indexados por <c>Clave</c>.
/// </param>
/// <param name="Partidas">El contexto de cada partida facturada, en el orden en que deben repetirse.</param>
public sealed record FacturaAddendaContexto(
    Guid IdTPPedido,
    IReadOnlyDictionary<string, string> CamposDerivados,
    IReadOnlyDictionary<string, string> ValoresGenuinos,
    IReadOnlyList<PartidaAddendaContexto> Partidas);
