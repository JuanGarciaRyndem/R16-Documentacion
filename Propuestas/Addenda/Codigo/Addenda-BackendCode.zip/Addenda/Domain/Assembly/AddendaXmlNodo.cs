namespace Addenda.Domain.Assembly;

/// <summary>
/// Árbol neutral que produce <see cref="AddendaAssembler"/>. No depende de ninguna tecnología XML
/// concreta a propósito: el dominio no conoce <c>System.Xml</c> (ver ryndem-dotnet/02, "el dominio
/// no depende de nada"). Un serializador de infraestructura lo convierte a XML real.
/// </summary>
public sealed class AddendaXmlNodo
{
    public required string Nombre { get; init; }

    /// <summary>Contenido de texto del nodo, cuando el campo se serializa como elemento hoja.</summary>
    public string? Valor { get; init; }

    public IReadOnlyDictionary<string, string> Atributos { get; init; } = new Dictionary<string, string>();

    public IReadOnlyList<AddendaXmlNodo> Hijos { get; init; } = [];
}
