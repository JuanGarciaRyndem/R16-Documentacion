using Addenda.API.Extensions;
using Addenda.API.Options;
using Addenda.Domain.Errors;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.Options;

namespace Addenda.API.ExceptionHandlers;

/// <summary>
/// Atiende cualquier excepción que no sea una <see cref="SemanticException"/> — es decir, cualquier
/// bug no clasificado. Responde con el código de fallback <c>UNX-001</c> y nunca expone al cliente
/// la traza de pila ni el mensaje de la excepción (ryndem-dotnet/05): el detalle completo va al
/// registro bajo el mismo <c>correlationId</c> que sí recibe el cliente. Registrado después de
/// <see cref="SemanticExceptionHandler"/> en <c>Program.cs</c>, para que este sea el que atiende
/// todo lo que aquel no reconoció.
/// </summary>
public sealed class GlobalFallbackExceptionHandler : IExceptionHandler
{
    private readonly ILogger<GlobalFallbackExceptionHandler> _logger;
    private readonly ProblemDetailsSettings _problemDetailsSettings;

    public GlobalFallbackExceptionHandler(ILogger<GlobalFallbackExceptionHandler> logger, IOptions<ProblemDetailsSettings> problemDetailsSettings)
    {
        _logger = logger;
        _problemDetailsSettings = problemDetailsSettings.Value;
    }

    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        var correlationId = httpContext.TraceIdentifier;

        _logger.LogError(exception, "Unhandled exception in Addenda ({CorrelationId})", correlationId);

        var problemDetails = ProblemDetailsMapper.ToProblemDetails(
            AddendaErrors.Generico.NoClasificado,
            correlationId,
            _problemDetailsSettings.TypeBase);

        httpContext.Response.StatusCode = problemDetails.Status ?? StatusCodes.Status500InternalServerError;
        httpContext.Response.ContentType = "application/problem+json";
        await httpContext.Response.WriteAsJsonAsync(problemDetails, cancellationToken);

        return true;
    }
}
