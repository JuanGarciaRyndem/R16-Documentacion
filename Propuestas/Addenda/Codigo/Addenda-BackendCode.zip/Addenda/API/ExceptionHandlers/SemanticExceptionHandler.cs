using Addenda.API.Extensions;
using Addenda.API.Options;
using Addenda.Domain.Errors;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Addenda.API.ExceptionHandlers;

/// <summary>
/// Atiende toda <see cref="SemanticException"/> no capturada: traduce su <see cref="ErrorDefinition"/>
/// a la respuesta <c>application/problem+json</c> estandarizada. El nivel de log lo determina
/// <see cref="ErrorDefinition.Severity"/>, nunca el criterio de quien lanzó la excepción — es lo que
/// dice ryndem-dotnet/05: "el nivel de log deja de ser criterio individual de cada desarrollador".
/// </summary>
public sealed class SemanticExceptionHandler : IExceptionHandler
{
    private readonly ILogger<SemanticExceptionHandler> _logger;
    private readonly ProblemDetailsSettings _problemDetailsSettings;

    public SemanticExceptionHandler(ILogger<SemanticExceptionHandler> logger, IOptions<ProblemDetailsSettings> problemDetailsSettings)
    {
        _logger = logger;
        _problemDetailsSettings = problemDetailsSettings.Value;
    }

    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        if (exception is not SemanticException semanticException)
        {
            return false;
        }

        var error = semanticException.Error;
        var correlationId = httpContext.TraceIdentifier;

        Log(error, correlationId, semanticException);

        var problemDetails = ProblemDetailsMapper.ToProblemDetails(error, correlationId, _problemDetailsSettings.TypeBase);

        httpContext.Response.StatusCode = problemDetails.Status ?? StatusCodes.Status500InternalServerError;
        httpContext.Response.ContentType = "application/problem+json";
        await httpContext.Response.WriteAsJsonAsync(problemDetails, cancellationToken);

        return true;
    }

    private void Log(ErrorDefinition error, string correlationId, SemanticException exception)
    {
        var logLevel = error.Severity switch
        {
            ErrorSeverity.Low => LogLevel.Warning,
            ErrorSeverity.Medium => LogLevel.Warning,
            ErrorSeverity.High => LogLevel.Error,
            ErrorSeverity.Critical => LogLevel.Error,
            _ => LogLevel.Error,
        };

        _logger.Log(
            logLevel,
            exception,
            "Addenda semantic error {Code} ({CorrelationId}): {Description}",
            error.Code,
            correlationId,
            error.Description);
    }
}
