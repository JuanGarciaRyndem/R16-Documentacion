using Addenda.Domain.Errors;

// Alias explícito: Microsoft.AspNetCore.Http (using implícito de Microsoft.NET.Sdk.Web) y
// Microsoft.AspNetCore.Mvc declaran cada uno su propio tipo "ProblemDetails" — sin este alias,
// el nombre sin calificar es ambiguo (CS0104) en cualquier proyecto Sdk.Web.
using ProblemDetails = Microsoft.AspNetCore.Mvc.ProblemDetails;

namespace Addenda.API.Extensions;

/// <summary>
/// Traduce un <see cref="ErrorDefinition"/> a la respuesta <c>application/problem+json</c>
/// estandarizada (RFC 9457) que exige ryndem-dotnet/05: <c>type</c>, <c>title</c>, <c>status</c>,
/// más las extensiones <c>code</c> y <c>correlationId</c>. Esto no es "el controller capturando una
/// excepción para traducirla" — un <c>Result</c> fallido nunca fue una excepción; es la forma normal
/// en que un flujo esperado se convierte en respuesta HTTP.
/// </summary>
public static class ProblemDetailsMapper
{
    /// <param name="error">La entrada del catálogo que describe la falla.</param>
    /// <param name="correlationId">Identificador único de la petición (<c>HttpContext.TraceIdentifier</c>).</param>
    /// <param name="typeBase">Base configurable del campo <c>type</c> (ver <c>ProblemDetails:TypeBase</c>).</param>
    /// <param name="erroresAdicionales">
    /// Entradas extra del catálogo, para el único caso en que <see cref="Domain.Common.Result"/>
    /// transporta más de un error: la validación de entrada (VAL-001 repetido, uno por campo).
    /// </param>
    public static ProblemDetails ToProblemDetails(
        ErrorDefinition error,
        string correlationId,
        string typeBase,
        IReadOnlyList<ErrorDefinition>? erroresAdicionales = null)
    {
        var problemDetails = new ProblemDetails
        {
            Type = $"{typeBase.TrimEnd('/')}/{error.Code}",
            Title = error.Title,
            Status = error.HttpStatusCode,
        };

        problemDetails.Extensions["code"] = error.Code;
        problemDetails.Extensions["correlationId"] = correlationId;

        if (erroresAdicionales is { Count: > 1 })
        {
            problemDetails.Extensions["errors"] = erroresAdicionales
                .Select(e => new { code = e.Code, detail = e.Description })
                .ToList();
        }

        return problemDetails;
    }
}
