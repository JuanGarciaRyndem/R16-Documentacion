using Addenda.API.ExceptionHandlers;
using Addenda.API.Options;
using Microsoft.Extensions.Configuration;

namespace Addenda.API.Extensions;

/// <summary>
/// Registra la capa de API: controllers, manejo global de excepciones y configuración tipada.
/// Cada capa expone su propio método de extensión; el punto de entrada los compone. Ver ryndem-dotnet/02.
/// </summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApiServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<ProblemDetailsSettings>(configuration.GetSection("ProblemDetails"));

        services.AddControllers();
        services.AddEndpointsApiExplorer();
        services.AddOpenApi();

        // Orden importa: SemanticExceptionHandler primero (más específico), el fallback después
        // para todo lo que aquel no reconoce. Ver ambos handlers.
        services.AddExceptionHandler<SemanticExceptionHandler>();
        services.AddExceptionHandler<GlobalFallbackExceptionHandler>();
        services.AddProblemDetails();

        return services;
    }
}
