namespace Addenda.API.Options;

/// <summary>
/// Configuración fuertemente tipada de la sección <c>ProblemDetails</c> (ryndem-dotnet/modern/02:
/// "la configuración se consume mediante opciones tipadas, no leyendo claves sueltas").
/// </summary>
public sealed class ProblemDetailsSettings
{
    /// <summary>
    /// Base del campo <c>type</c> de la respuesta de error. A falta de configuración, cada capa que
    /// la usa resuelve contra el propio servicio (ver ryndem-dotnet/05).
    /// </summary>
    public string TypeBase { get; set; } = "https://errors.ryndem.mx/addenda";
}
