using Addenda.API.Options;
using Addenda.Application.DTOs;
using Addenda.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Addenda.API.Controllers;

/// <summary>
/// Ensamblado y persistencia de la addenda de factura del pedido. Corresponde a las tareas BE-4,
/// BE-5, BE-7 y BE-8 de la estimación. Ver "[PROPUESTA] Adenda de Factura - Impacto en Backend.md".
/// </summary>
[ApiController]
[Route("api/[controller]")]
public sealed class AddendaController : ApiControllerBase
{
    private readonly IAddendaAssemblyService _assemblyService;
    private readonly IAddendaWriteService _writeService;

    public AddendaController(
        IAddendaAssemblyService assemblyService,
        IAddendaWriteService writeService,
        IOptions<ProblemDetailsSettings> problemDetailsSettings)
        : base(problemDetailsSettings)
    {
        _assemblyService = assemblyService;
        _writeService = writeService;
    }

    /// <summary>
    /// Assembles the <c>cfdi:Addenda</c> fragment for an order, ready to insert into the CFDI being
    /// stamped. Resolves the client's template against the invoice data supplied in the request and
    /// the genuine values captured earlier for that order (task BE-4/BE-5).
    /// </summary>
    /// <param name="request">The order's addenda type, invoice header data and line data.</param>
    /// <returns>The order id and the addenda XML fragment.</returns>
    /// <response code="200">Addenda assembled successfully.</response>
    /// <response code="400">The request does not meet the input validation rules.</response>
    /// <response code="404">The addenda type does not exist, is inactive, or has no template registered.</response>
    /// <response code="422">
    /// The template requires a genuine value (e.g. LineaDeOrden) that was not captured and has no
    /// default, or a conditional rule has no mapping for the resolved value.
    /// </response>
    [HttpPost("assemble")]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(AssembleAddendaResponseDto))]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    [ProducesResponseType(StatusCodes.Status422UnprocessableEntity, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    public async Task<ActionResult<AssembleAddendaResponseDto>> Assemble(
        [FromBody] AssembleAddendaRequestDto request,
        CancellationToken cancellationToken)
    {
        var result = await _assemblyService.AssembleAsync(request, cancellationToken);
        return ToActionResult(result);
    }

    /// <summary>
    /// Validates that an order's addenda can be assembled, without producing the XML. Intended to
    /// run before stamping so a missing genuine value rejects the attempt with a clear error
    /// instead of producing an incomplete CFDI (task BE-7).
    /// </summary>
    /// <param name="request">The same shape as <see cref="Assemble"/>.</param>
    /// <returns>No content when the addenda can be assembled.</returns>
    /// <response code="204">The addenda can be assembled: all required data is present.</response>
    /// <response code="400">The request does not meet the input validation rules.</response>
    /// <response code="404">The addenda type does not exist, is inactive, or has no template registered.</response>
    /// <response code="422">A required genuine value is missing, or a conditional rule has no mapping.</response>
    [HttpPost("validate")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    [ProducesResponseType(StatusCodes.Status422UnprocessableEntity, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    public async Task<ActionResult> Validate([FromBody] AssembleAddendaRequestDto request, CancellationToken cancellationToken)
    {
        var result = await _assemblyService.ValidateAsync(request, cancellationToken);
        return ToActionResult(result);
    }

    /// <summary>
    /// Saves the genuine addenda values captured for an order (e.g. LineaDeOrden per line, or
    /// CorreoContacto for the Sanofi family) — the only data addenda needs that does not already
    /// exist elsewhere in the invoice. Header and line values are committed as a single transaction
    /// (task BE-8).
    /// </summary>
    /// <param name="request">The order, its addenda type, and the captured header/line values.</param>
    /// <returns>No content when the values were saved.</returns>
    /// <response code="204">Values saved successfully.</response>
    /// <response code="400">The request does not meet the input validation rules.</response>
    /// <response code="404">The addenda type does not exist or is inactive.</response>
    [HttpPost("values")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    [ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(Microsoft.AspNetCore.Mvc.ProblemDetails))]
    public async Task<ActionResult> SaveValues([FromBody] SaveAddendaValuesRequestDto request, CancellationToken cancellationToken)
    {
        var result = await _writeService.SaveValuesAsync(request, cancellationToken);
        return ToActionResult(result);
    }
}
