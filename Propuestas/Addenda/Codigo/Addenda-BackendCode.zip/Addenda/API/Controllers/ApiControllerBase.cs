using Addenda.API.Extensions;
using Addenda.API.Options;
using Addenda.Domain.Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Addenda.API.Controllers;

/// <summary>
/// Traduce un <see cref="Result"/>/<see cref="Result{T}"/> a <see cref="ActionResult"/>. Es el único
/// lugar del API que conoce este mapeo — los controllers concretos solo exponen operaciones, sin
/// ninguna regla de negocio ni traducción propia (ryndem-dotnet/02, "Controllers").
/// </summary>
public abstract class ApiControllerBase : ControllerBase
{
    private readonly ProblemDetailsSettings _problemDetailsSettings;

    protected ApiControllerBase(IOptions<ProblemDetailsSettings> problemDetailsSettings)
    {
        _problemDetailsSettings = problemDetailsSettings.Value;
    }

    protected ActionResult<T> ToActionResult<T>(Result<T> result) =>
        result.IsSuccess ? Ok(result.Value) : BuildProblemResult(result);

    protected ActionResult ToActionResult(Result result) =>
        result.IsSuccess ? NoContent() : BuildProblemResult(result);

    private ObjectResult BuildProblemResult(Result result)
    {
        var problemDetails = ProblemDetailsMapper.ToProblemDetails(
            result.Error,
            HttpContext.TraceIdentifier,
            _problemDetailsSettings.TypeBase,
            result.Errors);

        return new ObjectResult(problemDetails) { StatusCode = problemDetails.Status };
    }
}
