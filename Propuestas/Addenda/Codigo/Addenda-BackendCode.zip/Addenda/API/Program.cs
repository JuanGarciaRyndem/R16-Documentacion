using Addenda.API.Extensions;
using Addenda.Application.Extensions;
using Addenda.Infrastructure.Extensions;

var builder = WebApplication.CreateBuilder(args);

builder.Services
    .AddApplication()
    .AddInfrastructure(builder.Configuration)
    .AddApiServices(builder.Configuration);

var app = builder.Build();

// Sin migraciones automáticas al arrancar (ryndem-dotnet/11): el esquema de catTipoAddenda /
// fccAddenda / fccAddendaPartida se aplica por pipeline de despliegue, no aquí.

app.UseExceptionHandler();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();
app.MapControllers();

app.Run();

// Visible para pruebas de integración (WebApplicationFactory<Program>) — patrón estándar de
// minimal hosting con top-level statements. Ver ryndem-dotnet/09-testing.
public partial class Program;
