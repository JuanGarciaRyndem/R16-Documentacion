# Addenda de Factura — código standalone (.NET 10)

Implementación de la propuesta **"[PROPUESTA] Adenda de Factura - Impacto en Backend.md"**: el
motor de plantillas data-driven del lado de Finanzas que ensambla el `cfdi:Addenda` de un pedido a
partir de una plantilla declarativa por cliente, sin código nuevo por cada cliente que se agregue.

## Alcance de este código

Cubre **solo el lado de Finanzas** (sección 5 del documento de Backend): el motor de ensamblado, las
4 plantillas reales (Mavi, Pfizer, Asofarma, Sanofi/Sanofi Pasteur/Azteca Vacunas) y el modelo de
datos genérico (`catTipoAddenda`, `fccAddenda`, `fccAddendaPartida`, ver el documento de BD).

**No** incluye los cambios del lado de pqf (sección 4 del documento de Backend: generalizar
L03/L04/L05 de `ProquifaDotNet` para que escriban en el modelo genérico en vez de las tablas
específicas de Sanofi) — ese código vive en otra solución que este sandbox no tiene forma de
localizar ni de tocar (ver "Por qué es standalone" abajo).

## Por qué es standalone

Se pidió generar el código "en base a la solución de Finanzas", pero ese repositorio no está
accesible desde este entorno: no se encontró en las rutas de trabajo del equipo (`source\repos`
solo tenía `HangFireTest2`, `NewRepo`, `TiendaServicios`). Ante esto se optó explícitamente por
generar una solución standalone que seguirlos estándares de `.NET` de Ryndem
(`ryndem-standards:ryndem-dotnet`), para que se integre manualmente al repositorio real de Finanzas
cuando se tenga acceso a él — copiando cada carpeta de capa a su lugar equivalente y resolviendo los
`namespace` según la convención de esa solución.

## Estructura

Clean Architecture de 4 capas + proyecto de pruebas, tal como exige el estándar:

```
Domain/          Entidades, Result, catálogo de errores, contratos de repositorio, el motor de
                 ensamblado (AddendaAssembler) y el modelo de plantillas — en español, sin
                 dependencias externas.
Application/     DTOs, validadores (FluentValidation), servicios de orquestación — en inglés
                 (ADR-0004), sin acceso a datos directo.
Infrastructure/  EF Core (DbContext, Fluent API, repositorios), las 4 plantillas reales
                 (Templates/Definitions), el serializador XML (System.Xml.Linq).
API/             Controllers, manejo global de excepciones (RFC 9457), Program.cs, appsettings.
Testing/         MSTest — motor genérico, las 4 plantillas contra los ejemplos reales del PDF,
                 serializador, mapeo de contexto, catálogo de errores, traducción a ProblemDetails.
```

## Por qué el dominio está en español y el resto en inglés

Es una decisión deliberada, no una inconsistencia: `Domain` modela el mismo vocabulario que ya usan
los documentos de la propuesta y el esquema legado (`fccAddenda`, `LineaDeOrden`, `CorreoContacto`),
mientras que `Application`/`API` exponen el contrato público en inglés porque así lo exige el
`ADR-0004` de los estándares de Ryndem. `ClavesDeCamposDerivados` (Domain) y `AddendaContextMapper`
(Application) son las dos únicas piezas que conocen ambos vocabularios a la vez.

## Decisión de diseño central: plantillas declarativas, no una clase por cliente

`AddendaAssembler` (Domain) es un único motor genérico que interpreta un árbol de
`AddendaNodoDefinicion`/`AddendaCampoDefinicion`. Agregar un cliente que reutiliza un formato ya
existente (p. ej. otro cliente con el formato Sanofi) es una entrada nueva en
`AddendaTemplateProvider` (Infrastructure), **no una clase nueva**. Las 4 plantillas reales están en
`Infrastructure/Templates/Definitions/`, construidas campo por campo a partir de
`INFORMACIÓN DE NODOS DE ADENDAS.pdf` (los ejemplos literales del PDF están citados en el
`<remarks>` de cada factory).

## Limitación de este entorno: código no compilado ni ejecutado

**Este sandbox no tiene el SDK de .NET instalado** (`dotnet --version` falla) **y el acceso a red
está restringido a los registros permitidos** — los intentos de instalar el SDK desde `dot.net` y
`packages.microsoft.com` fueron rechazados con `403 Forbidden`. Como consecuencia:

- El código se escribió y se revisó línea por línea contra los estándares y contra los ejemplos
  reales del PDF, pero **no se compiló ni se corrieron las pruebas en este entorno**.
- Antes de integrarlo, correr en un entorno con el SDK de .NET 10:
  ```
  dotnet restore
  dotnet build
  dotnet test
  ```
- Dos puntos que merecen atención especial al compilar por primera vez (quedaron documentados en el
  código, pero son el tipo de detalle que solo un compilador real confirma):
  - `Infrastructure/Xml/AddendaXmlSerializer.cs`: la resolución de namespaces XML (prefijo `sanofi`,
    `xsi:schemaLocation`) vía `System.Xml.Linq`. La lógica sigue el patrón estándar de la librería,
    pero el orden exacto de atributos en el fragmento de Sanofi no se pudo verificar por ejecución
    — por eso `TemplateAssemblyIntegrationTests` valida ese caso por sub-cadenas y no por igualdad
    exacta de todo el XML (a diferencia de Mavi/Pfizer/Asofarma, donde sí se afirma el string
    completo).
  - Los alias de `ProblemDetails` en el proyecto `API` (`Microsoft.AspNetCore.Http.ProblemDetails`
    vs `Microsoft.AspNetCore.Mvc.ProblemDetails`, ambos en alcance por los *implicit usings* de
    `Microsoft.NET.Sdk.Web`) — ya resueltos con un alias explícito, pero conviene confirmarlo al
    compilar.

## Pendientes heredados de las propuestas (no resueltos por este código, resueltos por configuración cuando se resuelvan)

Estos son los mismos pendientes de "Impacto en BD" (sección 6) y "Impacto en Backend" (sección 8) —
el código ya está preparado para absorberlos sin cambios de estructura:

1. **Vigencia de Amece** — no aparece en el PDF de SAP; confirmar con negocio.
2. **Un `catTipoAddenda` por cliente de la familia Sanofi** — el código ya registra `SANOFI`,
   `SANOFI_PASTEUR` y `AZTECA_VACUNAS` como 3 entradas independientes en
   `AddendaTemplateProvider`, hoy con los mismos valores fijos (`NUM_PROVEEDOR`, correo default);
   ajustar solo esos parámetros si SAP confirma que difieren.
3. **`CUENTA_PUENTE` (Sanofi)** — modelado como campo genuino con default `"0000000000"`: si se
   confirma que es capturable, ya se puede llenar `fccAddendaPartida` con `Clave='CuentaPuente'`
   sin tocar código.
4. **Mapeo `IdCatUnidad` → texto de unidad de medida (Sanofi)** — este código asume que
   `InvoiceLineAddendaContextDto.UnitOfMeasureCode` ya llega resuelto a texto (p. ej. `"Pieza"`);
   la resolución del catálogo interno queda del lado de quien arma ese DTO.
5. **Mapeo `noProveedor` de Asofarma** — hoy son solo 2 valores (`PROVEEDORA`/`GOLOCAER`) sin
   default: un tercer emisor no mapeado falla el ensamblado con `ADD-006` en vez de adivinar.
6. **Validar contra el ambiente real "byte a byte"** (plan de rollout, sección 7, paso 4) — las
   pruebas de este repo son el punto de partida, no el reemplazo de esa validación.

## Próximos pasos sugeridos

1. Compilar y correr `dotnet test` en un entorno con el SDK de .NET 10.
2. Ubicar el repositorio real de Finanzas e integrar cada capa a su lugar equivalente (ver
   "Por qué es standalone").
3. Generalizar pqf (L03/L04/L05) según la sección 4 del documento de Backend — fuera del alcance de
   este código.
4. Aplicar el esquema de BD (`catTipoAddenda`, `fccAddenda`, `fccAddendaPartida`) y correr el plan
   de rollout de la sección 7 del documento de Backend.
